"""
评估与反馈模块测试 (V3 新增)

测试覆盖:
  1. PerformanceDB: 推荐记录与追踪结果的 CRUD
  2. OutcomeTracker: T+N 结果追踪逻辑
  3. FeedbackInjector: 反馈上下文生成与注入
  4. AttributionEngine: 多维归因分析
  5. ParamOptimizer: 参数调优建议生成
  6. BacktestRunner: 交易日生成与报告生成

使用方式:
    cd short-term-stock-agent
    python -m pytest tests/test_eval_module.py -v
"""
import os
import sys
import json
import tempfile
import sqlite3
from datetime import datetime, timedelta

import pytest

# 确保项目根目录在 sys.path 中
_PROJECT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)


@pytest.fixture
def temp_db_path():
    """创建临时数据库文件"""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    yield db_path
    # 清理
    if os.path.exists(db_path):
        os.unlink(db_path)


@pytest.fixture
def db(temp_db_path):
    """创建干净的 PerformanceDB 实例"""
    from stock_agent.eval.performance_db import PerformanceDB
    PerformanceDB._instance = None  # 重置单例
    instance = PerformanceDB(db_path=temp_db_path)
    yield instance
    PerformanceDB._instance = None


@pytest.fixture
def sample_portfolio():
    """样本推荐组合"""
    return [
        {
            "ticker": "000001",
            "name": "平安银行",
            "source": "hot_sector",
            "rating": "买入",
            "target_price": 15.0,
            "take_profit": 14.5,
            "stop_loss": 12.5,
            "confidence": 0.75,
            "risk_level": 3,
            "sector": "银行",
            "entry_price": 13.0,
        },
        {
            "ticker": "600519",
            "name": "贵州茅台",
            "source": "dark_horse",
            "rating": "看多",
            "target_price": 1800.0,
            "take_profit": 1750.0,
            "stop_loss": 1600.0,
            "confidence": 0.65,
            "risk_level": 2,
            "sector": "白酒",
            "entry_price": 1680.0,
        },
    ]


@pytest.fixture
def sample_analysis_reports():
    """样本分析报告"""
    return {
        "000001": {
            "fundamentals": {"rating": "看多", "confidence": 0.8},
            "technical": {"rating": "看多", "confidence": 0.7},
            "china_specific": {"rating": "中性", "confidence": 0.5},
            "stock_development": {"rating": "无催化", "confidence": 0.3},
        },
        "600519": {
            "fundamentals": {"rating": "看多", "confidence": 0.85},
            "technical": {"rating": "中性", "confidence": 0.5},
            "china_specific": {"rating": "看多", "confidence": 0.6},
            "stock_development": {"rating": "强催化", "confidence": 0.9},
        },
    }


# =================================================================
# 1. PerformanceDB 测试
# =================================================================

class TestPerformanceDB:
    """性能数据库测试"""

    def test_save_and_read_recommendations(self, db, sample_portfolio, sample_analysis_reports):
        """测试保存和读取推荐记录"""
        trade_date = "2025-06-15"
        count = db.save_recommendations(
            trade_date=trade_date,
            portfolio=sample_portfolio,
            user_config={"risk_preference": "balanced", "holding_period": "1-5"},
            analysis_reports=sample_analysis_reports,
        )
        assert count == 2

        recs = db.get_recommendations_by_date(trade_date)
        assert len(recs) == 2
        assert recs[0]["ticker"] in ("000001", "600519")

        # 验证维度评级已保存
        rec_by_ticker = {r["ticker"]: r for r in recs}
        assert rec_by_ticker["000001"]["fundamentals_rating"] == "看多"
        assert rec_by_ticker["600519"]["stock_development_rating"] == "强催化"

    def test_save_and_read_outcome(self, db, sample_portfolio, sample_analysis_reports):
        """测试保存和读取追踪结果"""
        trade_date = "2025-06-15"
        db.save_recommendations(trade_date, sample_portfolio, {}, sample_analysis_reports)

        success = db.save_outcome(
            trade_date=trade_date,
            ticker="000001",
            outcome="take_profit_hit",
            holding_days=3,
            entry_price=13.0,
            exit_price=14.5,
            return_pct=11.54,
            max_return_pct=12.3,
            max_drawdown_pct=-1.5,
            daily_prices=[13.2, 13.8, 14.5],
            benchmark_return_pct=2.1,
        )
        assert success is True

        outcomes = db.get_outcomes_by_date(trade_date)
        assert len(outcomes) == 1
        assert outcomes[0]["outcome"] == "take_profit_hit"
        assert outcomes[0]["return_pct"] == 11.54
        assert outcomes[0]["excess_return_pct"] == pytest.approx(9.44, rel=0.01)

    def test_untracked_recommendations(self, db, sample_portfolio, sample_analysis_reports):
        """测试获取未追踪推荐"""
        trade_date = "2025-06-15"
        db.save_recommendations(trade_date, sample_portfolio, {}, sample_analysis_reports)

        untracked = db.get_untracked_recommendations()
        assert len(untracked) == 2

        # 追踪一只后, 未追踪应减少
        db.save_outcome(trade_date, "000001", "held_to_expiry", 5, 13.0, 13.5, 3.85)
        untracked = db.get_untracked_recommendations()
        assert len(untracked) == 1
        assert untracked[0]["ticker"] == "600519"

    def test_performance_summary(self, db, sample_portfolio, sample_analysis_reports):
        """测试性能摘要查询"""
        trade_date = "2025-06-10"
        db.save_recommendations(trade_date, sample_portfolio, {}, sample_analysis_reports)

        # 添加追踪结果
        db.save_outcome(trade_date, "000001", "take_profit_hit", 3, 13.0, 14.5, 11.54,
                        benchmark_return_pct=2.0)
        db.save_outcome(trade_date, "600519", "stop_loss_hit", 2, 1680.0, 1590.0, -5.36,
                        benchmark_return_pct=1.0)

        summary = db.get_performance_summary(lookback_days=30)
        assert summary["tracked_count"] == 2
        assert summary["hit_count"] == 1
        assert summary["hit_rate"] == 0.5
        assert summary["avg_return_pct"] == pytest.approx(3.09, rel=0.1)

    def test_run_stats(self, db):
        """测试运行统计保存"""
        db.save_run_stats(
            trade_date="2025-06-15",
            total_recommendations=5,
            total_tracked=4,
            hit_count=3,
            avg_return_pct=2.5,
            sharpe_ratio=1.2,
            max_drawdown_pct=-3.0,
            benchmark_return_pct=1.0,
            market_regime="bull",
        )
        # 验证可重复读取 (通过 get_performance_summary 间接验证)


# =================================================================
# 2. FeedbackInjector 测试
# =================================================================

class TestFeedbackInjector:
    """反馈注入器测试"""

    def test_generate_feedback_empty_db(self, temp_db_path):
        """空数据库时应返回空字符串"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.feedback_injector import FeedbackInjector

        PerformanceDB._instance = None
        config = {
            "performance_db_path": temp_db_path,
            "feedback_injection_enabled": True,
            "feedback_min_tracked": 3,
        }
        injector = FeedbackInjector(config)
        feedback = injector.generate_feedback_context(analyst_name="fundamentals")
        assert feedback == ""
        PerformanceDB._instance = None

    def test_generate_feedback_with_data(self, temp_db_path, sample_portfolio,
                                          sample_analysis_reports):
        """有数据时应生成反馈文本"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.feedback_injector import FeedbackInjector

        PerformanceDB._instance = None
        db = PerformanceDB(db_path=temp_db_path)

        trade_date = "2025-06-10"
        db.save_recommendations(trade_date, sample_portfolio, {}, sample_analysis_reports)
        db.save_outcome(trade_date, "000001", "take_profit_hit", 3, 13.0, 14.5, 11.54,
                        benchmark_return_pct=2.0)
        db.save_outcome(trade_date, "600519", "stop_loss_hit", 2, 1680.0, 1590.0, -5.36,
                        benchmark_return_pct=1.0)

        config = {
            "performance_db_path": temp_db_path,
            "feedback_injection_enabled": True,
            "feedback_min_tracked": 1,
            "feedback_lookback_days": 30,
        }
        injector = FeedbackInjector(config)
        feedback = injector.generate_feedback_context(analyst_name="fundamentals")

        assert "反馈" in feedback
        assert "命中率" in feedback
        assert "fundamentals" in feedback or "看多" in feedback
        PerformanceDB._instance = None

    def test_get_feedback_from_config(self):
        """测试从 config 提取反馈"""
        from stock_agent.eval.feedback_injector import get_feedback_from_config

        # 空 config
        assert get_feedback_from_config({}, "fundamentals") == ""
        assert get_feedback_from_config(None, "fundamentals") == ""

        # 有反馈
        config = {
            "_feedback_context": {
                "general": "通用反馈",
                "fundamentals": "基本面反馈",
            }
        }
        assert get_feedback_from_config(config, "fundamentals") == "基本面反馈"
        assert get_feedback_from_config(config, "nonexistent") == "通用反馈"

    def test_inject_into_state(self, temp_db_path):
        """测试状态注入"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.feedback_injector import FeedbackInjector

        PerformanceDB._instance = None
        config = {
            "performance_db_path": temp_db_path,
            "feedback_injection_enabled": True,
            "feedback_min_tracked": 100,  # 高阈值, 确保不注入
        }
        injector = FeedbackInjector(config)
        state = {"trade_date": "2025-06-15"}
        state = injector.inject_into_state(state)

        assert "feedback_context" in state
        # 数据不足, 反馈应为空字符串
        assert state["feedback_context"]["general"] == ""
        PerformanceDB._instance = None


# =================================================================
# 3. AttributionEngine 测试
# =================================================================

class TestAttributionEngine:
    """归因分析引擎测试"""

    def test_attribution_empty_db(self, temp_db_path):
        """空数据库归因分析"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.attribution_engine import AttributionEngine

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path, "attribution_min_sample": 1}
        engine = AttributionEngine(config)
        report = engine.run_full_attribution(lookback_days=30)

        assert report["sample_size"] == 0
        assert report["overall"]["hit_rate"] == 0
        PerformanceDB._instance = None

    def test_attribution_with_data(self, temp_db_path, sample_portfolio,
                                    sample_analysis_reports):
        """有数据时归因分析"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.attribution_engine import AttributionEngine

        PerformanceDB._instance = None
        db = PerformanceDB(db_path=temp_db_path)

        trade_date = "2025-06-10"
        db.save_recommendations(trade_date, sample_portfolio, {}, sample_analysis_reports)
        db.save_outcome(trade_date, "000001", "take_profit_hit", 3, 13.0, 14.5, 11.54,
                        benchmark_return_pct=2.0)
        db.save_outcome(trade_date, "600519", "stop_loss_hit", 2, 1680.0, 1590.0, -5.36,
                        benchmark_return_pct=1.0)

        config = {"performance_db_path": temp_db_path, "attribution_min_sample": 1}
        engine = AttributionEngine(config)
        report = engine.run_full_attribution(lookback_days=30)

        assert report["sample_size"] == 2
        assert report["overall"]["hit_rate"] == 0.5
        assert "analyst_attribution" in report
        assert "sector_attribution" in report
        assert "optimization_suggestions" in report
        PerformanceDB._instance = None

    def test_attribution_report_text(self, temp_db_path):
        """测试归因报告文本生成"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.attribution_engine import AttributionEngine

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path}
        engine = AttributionEngine(config)
        text = engine.generate_attribution_report_text()

        assert "归因分析" in text
        PerformanceDB._instance = None


# =================================================================
# 4. ParamOptimizer 测试
# =================================================================

class TestParamOptimizer:
    """参数调优器测试"""

    def test_optimize_insufficient_data(self, temp_db_path):
        """数据不足时应跳过调优"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.param_optimizer import ParamOptimizer

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path}
        optimizer = ParamOptimizer(config)
        result = optimizer.optimize(lookback_days=30, dry_run=True)

        assert result["status"] == "skipped_insufficient_data"
        assert result["suggested_overrides"] == {}
        PerformanceDB._instance = None

    def test_optimization_report_text(self, temp_db_path):
        """测试调优报告文本生成"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.param_optimizer import ParamOptimizer

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path}
        optimizer = ParamOptimizer(config)
        text = optimizer.generate_optimization_report_text()

        assert "参数调优" in text
        PerformanceDB._instance = None


# =================================================================
# 5. BacktestRunner 测试
# =================================================================

class TestBacktestRunner:
    """批量回测调度器测试"""

    def test_generate_trade_dates(self, temp_db_path):
        """测试交易日生成 (跳过周末)"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.backtest_runner import BacktestRunner

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path}
        runner = BacktestRunner(config)
        dates = runner._generate_trade_dates("2025-06-02", "2025-06-08")

        # 6/2(周一) ~ 6/8(周日): 应有 5 个交易日 (周一~周五)
        assert len(dates) == 5
        assert "2025-06-02" in dates  # 周一
        assert "2025-06-06" in dates  # 周五
        assert "2025-06-07" not in dates  # 周六
        assert "2025-06-08" not in dates  # 周日
        PerformanceDB._instance = None

    def test_backtest_report_text(self, temp_db_path):
        """测试回测报告文本生成"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.backtest_runner import BacktestRunner

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path}
        runner = BacktestRunner(config)
        text = runner.generate_backtest_report_text()

        assert "回测统计" in text
        PerformanceDB._instance = None

    def test_invalid_date_format(self, temp_db_path):
        """测试无效日期格式"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.backtest_runner import BacktestRunner

        PerformanceDB._instance = None
        config = {"performance_db_path": temp_db_path}
        runner = BacktestRunner(config)
        dates = runner._generate_trade_dates("invalid", "2025-06-08")
        assert dates == []
        PerformanceDB._instance = None


# =================================================================
# 6. 集成测试
# =================================================================

class TestIntegration:
    """端到端集成测试"""

    def test_full_feedback_loop(self, temp_db_path, sample_portfolio,
                                 sample_analysis_reports):
        """测试完整反馈闭环: 保存推荐 → 追踪结果 → 归因分析 → 参数调优"""
        from stock_agent.eval.performance_db import PerformanceDB
        from stock_agent.eval.feedback_injector import FeedbackInjector
        from stock_agent.eval.attribution_engine import AttributionEngine
        from stock_agent.eval.param_optimizer import ParamOptimizer

        PerformanceDB._instance = None
        db = PerformanceDB(db_path=temp_db_path)

        # 1. 保存推荐
        trade_date = "2025-06-10"
        db.save_recommendations(trade_date, sample_portfolio, {}, sample_analysis_reports)

        # 2. 保存追踪结果
        db.save_outcome(trade_date, "000001", "take_profit_hit", 3, 13.0, 14.5, 11.54,
                        benchmark_return_pct=2.0)
        db.save_outcome(trade_date, "600519", "stop_loss_hit", 2, 1680.0, 1590.0, -5.36,
                        benchmark_return_pct=1.0)

        # 3. 归因分析
        config = {"performance_db_path": temp_db_path, "attribution_min_sample": 1}
        engine = AttributionEngine(config)
        report = engine.run_full_attribution(lookback_days=30)
        assert report["sample_size"] == 2

        # 4. 参数调优
        optimizer = ParamOptimizer(config)
        opt_result = optimizer.optimize(lookback_days=30, dry_run=True)
        assert opt_result["sample_size"] == 2

        # 5. 反馈注入
        injector = FeedbackInjector({
            "performance_db_path": temp_db_path,
            "feedback_min_tracked": 1,
        })
        feedback = injector.generate_feedback_context(analyst_name="fundamentals")
        assert "反馈" in feedback
        assert "命中率" in feedback

        PerformanceDB._instance = None

    def test_config_has_eval_settings(self):
        """测试默认配置包含评估模块配置项"""
        from stock_agent.default_config import DEFAULT_CONFIG

        assert "performance_db_path" in DEFAULT_CONFIG
        assert "feedback_injection_enabled" in DEFAULT_CONFIG
        assert "attribution_enabled" in DEFAULT_CONFIG
        assert "param_optimization_enabled" in DEFAULT_CONFIG
        assert "analyst_decision_weights" in DEFAULT_CONFIG
        assert DEFAULT_CONFIG["feedback_injection_enabled"] is True
