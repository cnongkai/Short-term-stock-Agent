"""
报告生成器 (对应 PRD Phase 8 / 全链路留痕)

读取全部状态字段, 生成 Markdown 推荐报告 + JSON 报告, 写入 results/ 目录。
无需 LLM 调用, 纯数据聚合与格式化。

输出文件:
  - results/recommendation_{date}.md  : 人类可读的 Markdown 报告 (含五维热力图)
  - results/recommendation_{date}.json: 机器可读的 JSON 报告 (含全链路状态)
  - results/sector_heatmap_{date}.html: 板块五维热力图 (CSS 渐变色, 浏览器可打开)
"""
import os
import json
from datetime import datetime
from loguru import logger


def create_report_generator():
    """创建报告生成器图节点 (无需 LLM)

    Returns:
        report_generator_node(state) -> dict: 无状态更新 (仅写文件)
    """

    def report_generator_node(state) -> dict:
        logger.info("[报告生成] 开始生成推荐报告")

        trade_date = state.get("trade_date", "unknown")
        portfolio = state.get("final_portfolio", [])
        candidate_pool = state.get("candidate_pool", [])
        ranked_sectors = state.get("ranked_sectors", [])
        circuit_breaker = state.get("circuit_breaker", False)

        # === 确定输出目录 ===
        results_dir = os.getenv("RESULTS_DIR", "./results")
        os.makedirs(results_dir, exist_ok=True)

        # === 生成 Markdown 报告 ===
        md_report = _build_markdown_report(state)
        md_path = os.path.join(results_dir, f"recommendation_{trade_date}.md")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md_report)
        logger.info(f"[报告生成] Markdown 报告: {md_path}")

        # === 生成 JSON 报告 (含全链路状态摘要) ===
        json_report = _build_json_report(state)
        json_path = os.path.join(results_dir, f"recommendation_{trade_date}.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(json_report, f, ensure_ascii=False, indent=2, default=str)
        logger.info(f"[报告生成] JSON 报告: {json_path}")

        # === 生成板块五维热力图 HTML ===
        crowding_map = state.get("sector_crowding_map", {})
        if crowding_map and crowding_map.get("top_10"):
            html_heatmap = _build_sector_heatmap_html(crowding_map, trade_date)
            html_path = os.path.join(results_dir, f"sector_heatmap_{trade_date}.html")
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html_heatmap)
            logger.info(f"[报告生成] 板块热力图: {html_path}")

        return {}  # 报告生成不更新状态

    return report_generator_node


def _build_markdown_report(state) -> str:
    """构建 Markdown 格式推荐报告"""
    trade_date = state.get("trade_date", "unknown")
    portfolio = state.get("final_portfolio", [])
    candidate_pool = state.get("candidate_pool", [])
    ranked_sectors = state.get("ranked_sectors", [])
    hot_topics = state.get("hot_topics", [])
    policy_events = state.get("policy_events", [])
    circuit_breaker = state.get("circuit_breaker", False)
    investment_plan = state.get("investment_plan", "")
    final_decision = state.get("final_trade_decision", "")

    lines = [
        f"# 短线股票推荐报告 — {trade_date}",
        "",
        f"> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"> 候选池: {len(candidate_pool)} 只 | 推荐标的: {len(portfolio)} 只",
        "",
    ]

    # === 熔断提示 ===
    if circuit_breaker:
        lines += [
            "## ⚠️ 熔断提示",
        "> 大盘单日跌幅超过阈值, 系统已暂停推荐 (PRD 10.2)",
            "",
        ]

    # === 推荐清单 ===
    lines += ["## 📊 最终推荐清单", ""]
    if portfolio:
        lines += [
            "| # | 代码 | 名称 | 来源 | 评级 | 目标价 | 止盈 | 止损 | 置信度 |",
            "|---|------|------|------|------|--------|------|------|--------|",
        ]
        for i, stock in enumerate(portfolio, 1):
            lines.append(
                f"| {i} | {stock.get('ticker','')} | {stock.get('name','')} | "
                f"{stock.get('source','')} | {stock.get('rating','')} | "
                f"¥{stock.get('target_price','')} | ¥{stock.get('take_profit','')} | "
                f"¥{stock.get('stop_loss','')} | {stock.get('confidence','')} |"
            )
    else:
        lines.append("本周期无推荐标的。")
    lines.append("")

    # === 热门板块 ===
    if ranked_sectors:
        lines += ["## 🔥 热门板块排名", ""]
        for i, sector in enumerate(ranked_sectors[:5], 1):
            lines.append(
                f"{i}. **{sector.get('sector','')}** — "
                f"热度: {sector.get('heat_score','')} | "
                f"趋势: {sector.get('trend','')} | "
                f"政策影响: {sector.get('policy_impact','')}"
            )
        lines.append("")

    # === 板块五维热力图 ===
    crowding_map = state.get("sector_crowding_map", {})
    if crowding_map and crowding_map.get("top_10"):
        lines += _build_sector_heatmap_md(crowding_map)

    # === 热点话题 ===
    if hot_topics:
        lines += ["## 📰 热点话题", ""]
        for topic in hot_topics[:10]:
            lines.append(
                f"- [{topic.get('source_type','')}] {topic.get('topic','')} "
                f"(情绪: {topic.get('sentiment_score','')}, 动量: {topic.get('momentum','')})"
            )
        lines.append("")

    # === 政策事件 ===
    if policy_events:
        lines += ["## 🏛️ 政策事件", ""]
        for event in policy_events[:5]:
            lines.append(
                f"- **{event.get('title','')}** — {event.get('authority_level','')} | "
                f"影响: {event.get('impact_direction','')}({event.get('impact_strength','')}) | "
                f"板块: {', '.join(event.get('affected_sectors',[]))}"
            )
        lines.append("")

    # === 候选池详情 ===
    if candidate_pool:
        lines += ["## 📋 候选池详情", ""]
        for stock in candidate_pool:
            lines.append(
                f"- {stock.get('ticker','')} {stock.get('name','')} "
                f"[{stock.get('source','')}] — {stock.get('reason','')}"
            )
        lines.append("")

    # === 投资计划摘要 ===
    if investment_plan:
        lines += ["## 📝 投资计划摘要", "", "```json", investment_plan[:2000], "```", ""]

    # === 风控决策摘要 ===
    if final_decision:
        lines += ["## 🛡️ 风控决策摘要", "", "```json", final_decision[:2000], "```", ""]

    lines.append("---")
    lines.append("> 本报告由短线股票推荐 Agent (PRD V2) 自动生成, 仅供参考, 不构成投资建议。")

    return "\n".join(lines)


def _build_json_report(state) -> dict:
    """构建 JSON 格式报告 (含全链路状态摘要)"""
    # 过滤不可序列化的 messages 字段
    serializable = {}
    for k, v in state.items():
        if k == "messages":
            continue
        try:
            json.dumps(v, default=str)
            serializable[k] = v
        except (TypeError, ValueError):
            serializable[k] = str(v)

    return {
        "trade_date": state.get("trade_date", ""),
        "generated_at": datetime.now().isoformat(),
        "summary": {
            "candidate_count": len(state.get("candidate_pool", [])),
            "recommended_count": len(state.get("final_portfolio", [])),
            "circuit_breaker": state.get("circuit_breaker", False),
            "hot_topics_count": len(state.get("hot_topics", [])),
            "policy_events_count": len(state.get("policy_events", [])),
            "ranked_sectors_count": len(state.get("ranked_sectors", [])),
        },
        "sector_heatmap": state.get("sector_crowding_map", {}),
        "final_portfolio": state.get("final_portfolio", []),
        "full_state": serializable,
    }


# =====================================================================
# 板块五维热力图 — 颜色映射工具
# =====================================================================
def _score_to_emoji(score: float) -> str:
    """分数 → emoji 指示器 (5 级颜色梯度)"""
    if score >= 80:
        return "🔴"
    if score >= 60:
        return "🟠"
    if score >= 40:
        return "🟡"
    if score >= 20:
        return "🟢"
    return "🔵"


def _score_to_bar(score: float, width: int = 20) -> str:
    """分数 → ASCII 进度条 (如 '████████████████░░░░ 80.0')"""
    filled = int(score / 100 * width)
    return "█" * filled + "░" * (width - filled) + f" {score:.1f}"


def _score_to_color(score: float) -> str:
    """分数 → CSS 颜色 (连续渐变: 蓝→绿→黄→橙→红)

    Returns:
        rgba(r, g, b, alpha) 字符串
    """
    s = max(0, min(100, score))
    if s >= 80:
        # 红 → 深红
        t = (s - 80) / 20
        r, g, b = 255, int(60 - 60 * t), int(60 - 60 * t)
    elif s >= 60:
        # 橙 → 红
        t = (s - 60) / 20
        r, g, b = 255, int(165 - 105 * t), int(0)
    elif s >= 40:
        # 黄 → 橙
        t = (s - 40) / 20
        r, g, b = 255, int(255 - 90 * t), int(0)
    elif s >= 20:
        # 绿 → 黄
        t = (s - 20) / 20
        r, g, b = int(50 + 205 * t), int(205 + 50 * t), int(50 - 50 * t)
    else:
        # 蓝 → 绿
        t = s / 20
        r, g, b = int(50 * t), int(100 + 105 * t), int(255 - 205 * t)
    alpha = 0.4 + s / 100 * 0.5  # 0.4 ~ 0.9
    return f"rgba({r}, {g}, {b}, {alpha:.2f})"


# =====================================================================
# 板块五维热力图 — Markdown 输出
# =====================================================================
_DIM_LABELS = [
    ("heat", "热度"),
    ("diffusion", "扩散力"),
    ("volatility", "动摇度"),
    ("rebound", "回补力"),
    ("crowding", "拥挤度"),
]


def _build_sector_heatmap_md(crowding_map: dict) -> list:
    """构建板块五维热力图 Markdown 区块

    输出两部分:
      1. Emoji 颜色表格 (每维度分数 + 🔴🟠🟡🟢🔵 指示器)
      2. Top 5 板块 ASCII 进度条 (直观对比五维得分)

    Args:
        crowding_map: sector_crowding_map (含 top_10 列表)

    Returns:
        Markdown 行列表
    """
    top_10 = crowding_map.get("top_10", [])
    if not top_10:
        return []

    lines = [
        "## 🌡️ 板块五维热力图",
        "",
        f"> 数据日期: {crowding_map.get('trade_date', 'N/A')} | 展示 Top {len(top_10)} 板块",
        "> 颜色梯度: 🔴 ≥80 极高 | 🟠 60-79 高 | 🟡 40-59 适中 | 🟢 20-39 低 | 🔵 <20 极低",
        "",
        "| # | 板块 | 热度 | 扩散力 | 动摇度 | 回补力 | 拥挤度 | 总分 | 环比 |",
        "|---|------|------|--------|--------|--------|--------|------|------|",
    ]

    for s in top_10:
        metrics = s.get("metrics", {})
        cells = []
        for key, _ in _DIM_LABELS:
            val = metrics.get(key, 0)
            try:
                val = float(val)
            except (TypeError, ValueError):
                val = 0.0
            cells.append(f"{val:.1f} {_score_to_emoji(val)}")

        lines.append(
            f"| {s['rank']} | {s['sector']} | "
            f"{cells[0]} | {cells[1]} | {cells[2]} | {cells[3]} | {cells[4]} | "
            f"**{s['total_score']:.1f}** | {s.get('mom_change', 'N/A')} |"
        )

    lines.append("")

    # === Top 5 ASCII 进度条 ===
    lines += ["### 📊 Top 5 板块五维对比", ""]

    for s in top_10[:5]:
        metrics = s.get("metrics", {})
        lines.append(f"**#{s['rank']} {s['sector']}** (总分 {s['total_score']:.1f})")
        for key, label in _DIM_LABELS:
            val = metrics.get(key, 0)
            try:
                val = float(val)
            except (TypeError, ValueError):
                val = 0.0
            lines.append(f"  {label:<4s} {_score_to_bar(val)}")
        lines.append("")

    return lines


# =====================================================================
# 板块五维热力图 — HTML 输出 (独立文件)
# =====================================================================
def _build_sector_heatmap_html(crowding_map: dict, trade_date: str) -> str:
    """构建板块五维热力图 HTML 文件 (CSS 渐变色, 浏览器可打开)

    生成一个独立的 HTML 文件, 包含:
      - CSS 渐变色热力图表格 (每个单元格背景色根据分数连续渐变)
      - 颜色图例 (蓝→绿→黄→橙→红)
      - 拥挤度标签 (极度拥挤/拥挤/适中/宽松/极度宽松)
      - 环比变化列

    Args:
        crowding_map: sector_crowding_map (含 top_10 列表)
        trade_date: 交易日期

    Returns:
        HTML 字符串
    """
    top_10 = crowding_map.get("top_10", [])

    # 构建表格行
    rows_html = []
    for s in top_10:
        metrics = s.get("metrics", {})
        cells = []
        for key, label in _DIM_LABELS:
            val = metrics.get(key, 0)
            try:
                val = float(val)
            except (TypeError, ValueError):
                val = 0.0
            color = _score_to_color(val)
            cells.append(
                f'<td class="heatmap-cell" style="background-color: {color};" '
                f'title="{label}: {val:.1f}">{val:.1f}</td>'
            )

        crowding_val = s.get("crowding", 0)
        try:
            crowding_val = float(crowding_val)
        except (TypeError, ValueError):
            crowding_val = 0.0
        crowding_color = _score_to_color(crowding_val)
        crowding_icon = s.get("icon", "")
        crowding_label = s.get("label", "")

        mom = s.get("mom_change", "N/A")
        mom_color = "#666" if "N/A" in str(mom) else ("#e53e3e" if "+" in str(mom) else "#38a169")

        rows_html.append(
            f"<tr>"
            f'<td class="rank-cell">{s["rank"]}</td>'
            f'<td class="sector-cell">{s["sector"]}</td>'
            f"{''.join(cells)}"
            f'<td class="heatmap-cell" style="background-color: {crowding_color};">'
            f'{crowding_val:.1f} {crowding_icon}</td>'
            f'<td class="total-cell"><strong>{s["total_score"]:.1f}</strong></td>'
            f'<td class="mom-cell" style="color: {mom_color};">{mom}</td>'
            f'<td class="label-cell">{crowding_label}</td>'
            f"</tr>"
        )

    rows = "\n        ".join(rows_html)
    generated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>板块五维热力图 — {trade_date}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
            background: #f5f7fa;
            color: #333;
            padding: 24px;
        }}
        h1 {{
            font-size: 22px;
            margin-bottom: 8px;
            color: #1a202c;
        }}
        .meta {{
            color: #718096;
            font-size: 13px;
            margin-bottom: 20px;
        }}
        .legend {{
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            font-size: 13px;
            color: #4a5568;
        }}
        .legend-bar {{
            width: 240px;
            height: 16px;
            border-radius: 4px;
            background: linear-gradient(to right,
                rgba(0, 100, 255, 0.7),
                rgba(50, 205, 50, 0.7),
                rgba(255, 255, 0, 0.7),
                rgba(255, 165, 0, 0.7),
                rgba(255, 0, 0, 0.7));
        }}
        .legend-labels {{
            display: flex;
            justify-content: space-between;
            width: 240px;
            font-size: 11px;
            color: #718096;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }}
        th {{
            background: #2d3748;
            color: #fff;
            font-weight: 600;
            padding: 12px 10px;
            text-align: center;
            font-size: 14px;
            white-space: nowrap;
        }}
        th:first-child {{ width: 40px; }}
        th.sector-header {{ text-align: left; min-width: 100px; }}
        td {{
            padding: 10px 8px;
            text-align: center;
            font-size: 14px;
            border-bottom: 1px solid #e2e8f0;
        }}
        .rank-cell {{
            font-weight: 700;
            color: #718096;
            width: 40px;
        }}
        .sector-cell {{
            text-align: left;
            font-weight: 600;
            color: #1a202c;
        }}
        .heatmap-cell {{
            font-variant-numeric: tabular-nums;
            color: #1a202c;
            min-width: 70px;
            transition: transform 0.15s;
        }}
        .heatmap-cell:hover {{
            transform: scale(1.1);
            z-index: 1;
            position: relative;
        }}
        .total-cell {{
            font-size: 15px;
            color: #1a202c;
        }}
        .mom-cell {{
            font-variant-numeric: tabular-nums;
            font-weight: 600;
        }}
        .label-cell {{
            font-size: 12px;
            color: #718096;
            white-space: nowrap;
        }}
        tr:hover {{
            background-color: #f7fafc;
        }}
        tr:hover .heatmap-cell {{
            opacity: 0.92;
        }}
        .footer {{
            margin-top: 16px;
            font-size: 12px;
            color: #a0aec0;
            text-align: center;
        }}
    </style>
</head>
<body>
    <h1>🌡️ 板块五维热力图</h1>
    <div class="meta">
        交易日期: {trade_date} &nbsp;|&nbsp; 生成时间: {generated} &nbsp;|&nbsp;
        展示 Top {len(top_10)} 板块
    </div>

    <div class="legend">
        <span>分数:</span>
        <div>
            <div class="legend-bar"></div>
            <div class="legend-labels">
                <span>0 极低</span>
                <span>25</span>
                <span>50 适中</span>
                <span>75</span>
                <span>100 极高</span>
            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th class="sector-header">板块</th>
                <th>热度</th>
                <th>扩散力</th>
                <th>动摇度</th>
                <th>回补力</th>
                <th>拥挤度</th>
                <th>总分</th>
                <th>环比</th>
                <th>拥挤标签</th>
            </tr>
        </thead>
        <tbody>
        {rows}
        </tbody>
    </table>

    <div class="footer">
        五维评分: 热度(资金+注意力) · 扩散力(上涨广度) · 动摇度(波动) · 回补力(上行动能) · 拥挤度(交易拥挤) |
        由短线股票推荐 Agent 自动生成
    </div>
</body>
</html>"""
