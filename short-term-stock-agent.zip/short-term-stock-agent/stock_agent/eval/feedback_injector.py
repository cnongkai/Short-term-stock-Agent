"""
Prompt 反馈注入器 (V3 新增, 对应升级方案阶段二)

在 Agent 运行前, 从 PerformanceDB 提取近期表现摘要, 注入到各分析师的
System Prompt 中, 使其"看到"自己过去的成功与失败模式。

参考 ACE (Agentic Context Engineering) 框架:
  - 反馈上下文以结构化条目形式增量注入, 而非整段重写 Prompt
  - 避免上下文塌缩 (context collapse) 和简写偏差
  - 条目各自独立, 可独立增删

注入位置: 在现有 SKILL 六段结构 (角色/设定/目标/SKILL/输出/限制) 之后,
新增第七段 "反馈" (feedback), 包含历史命中率、失败模式、调整建议。

使用方式:
    from stock_agent.eval.feedback_injector import FeedbackInjector
    injector = FeedbackInjector(config)
    feedback = injector.generate_feedback_context(analyst_name="fundamentals")
    # feedback 为结构化文本, 可追加到 system_prompt 末尾

    # 或在 propagation 时自动注入:
    injector.inject_into_state(state)
"""
from typing import Dict, Optional
from loguru import logger

from stock_agent.eval.performance_db import PerformanceDB


class FeedbackInjector:
    """Prompt 反馈注入器

    从 PerformanceDB 查询近期表现, 生成结构化反馈文本, 注入分析师 Prompt。
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.db = PerformanceDB(
            db_path=self.config.get("performance_db_path")
        )
        self.lookback_days = int(self.config.get("feedback_lookback_days", 30))
        self.enabled = self.config.get("feedback_injection_enabled", True)
        self.min_tracked_for_injection = int(
            self.config.get("feedback_min_tracked", 3)
        )

    def generate_feedback_context(
        self,
        analyst_name: Optional[str] = None,
        lookback_days: int = None,
    ) -> str:
        """生成反馈上下文文本 (注入到 System Prompt)

        Args:
            analyst_name: 分析师名称 (fundamentals/technical/china_specific/
                         stock_development), None 则生成通用反馈
            lookback_days: 回看天数 (None 则用配置默认值)

        Returns:
            结构化反馈文本 (如果数据不足或未启用, 返回空字符串)
        """
        if not self.enabled:
            return ""

        days = lookback_days or self.lookback_days

        try:
            stats = self.db.get_performance_summary(lookback_days=days)
        except Exception as e:
            logger.warning(f"[反馈] 获取性能摘要失败: {e}")
            return ""

        # 数据不足时不注入
        if stats["tracked_count"] < self.min_tracked_for_injection:
            logger.info(
                f"[反馈] 追踪数据不足 ({stats['tracked_count']}<{self.min_tracked_for_injection}), 跳过注入"
            )
            return ""

        lines = []
        lines.append("")
        lines.append("=== 【反馈】历史表现回顾 (近{}天) ===".format(days))
        lines.append("")

        # === 整体指标 ===
        lines.append("整体表现:")
        lines.append(
            f"  - 推荐标的数: {stats['total_count']} | 已追踪: {stats['tracked_count']}"
        )
        lines.append(
            f"  - 命中率: {stats['hit_rate']:.1%} | 平均收益: {stats['avg_return_pct']:+.2f}%"
        )
        lines.append(
            f"  - 夏普比率: {stats['sharpe_ratio']:.2f} | 最大回撤: {stats['max_drawdown_pct']:.2f}%"
        )
        if stats.get("avg_excess_return_pct"):
            lines.append(
                f"  - 超额收益(vs基准): {stats['avg_excess_return_pct']:+.2f}%"
            )
        lines.append("")

        # === 按板块表现 (Top 3 + Bottom 3) ===
        by_sector = stats.get("by_sector", {})
        if by_sector:
            sorted_sectors = sorted(
                by_sector.items(),
                key=lambda x: x[1].get("avg_return", 0),
                reverse=True,
            )
            lines.append("板块表现 (按平均收益排序):")
            # Top 3
            for sector, s in sorted_sectors[:3]:
                lines.append(
                    f"  ✓ {sector}: 命中率{s['hit_rate']:.0%} "
                    f"平均收益{s['avg_return']:+.2f}% ({s['count']}只)"
                )
            # Bottom 3
            if len(sorted_sectors) > 3:
                lines.append("  ---")
                for sector, s in sorted_sectors[-3:]:
                    lines.append(
                        f"  ✗ {sector}: 命中率{s['hit_rate']:.0%} "
                        f"平均收益{s['avg_return']:+.2f}% ({s['count']}只)"
                    )
            lines.append("")

        # === 分析师维度归因 (如果指定了 analyst_name) ===
        if analyst_name:
            by_analyst = stats.get("by_analyst", {})
            dim_stats = by_analyst.get(analyst_name, {})
            if dim_stats:
                lines.append(f"本维度({analyst_name})历史评级准确度:")
                for rating, s in sorted(
                    dim_stats.items(),
                    key=lambda x: x[1].get("avg_return", 0),
                    reverse=True,
                ):
                    lines.append(
                        f"  {rating}: 命中率{s['hit_rate']:.0%} "
                        f"平均收益{s['avg_return']:+.2f}% ({s['count']}次)"
                    )
                lines.append("")

        # === 置信度校准 ===
        by_conf = stats.get("by_confidence", {})
        if by_conf:
            lines.append("置信度校准:")
            for bucket in ["high", "medium", "low"]:
                s = by_conf.get(bucket, {})
                if s:
                    lines.append(
                        f"  {bucket}(conf≥{'0.7' if bucket=='high' else '0.5' if bucket=='medium' else '<0.5'}): "
                        f"命中率{s['hit_rate']:.0%} 平均收益{s.get('avg_return', 0):+.2f}%"
                    )
            lines.append("")

        # === 失败模式 ===
        failures = stats.get("failure_patterns", [])
        if failures:
            lines.append("常见失败模式 (需规避):")
            for f in failures[:3]:
                lines.append(
                    f"  - {f['pattern']}: {f['count']}次 平均亏损{f['avg_return']:+.2f}%"
                )
            lines.append("")

        # === 调整建议 ===
        suggestions = self._generate_suggestions(stats, analyst_name)
        if suggestions:
            lines.append("调整建议:")
            for s in suggestions:
                lines.append(f"  → {s}")
            lines.append("")

        lines.append("=== 反馈结束 ===")

        feedback_text = "\n".join(lines)
        logger.info(
            f"[反馈] 生成反馈上下文 ({len(feedback_text)} 字符, "
            f"analyst={analyst_name or 'general'}, tracked={stats['tracked_count']})"
        )
        return feedback_text

    def _generate_suggestions(self, stats: dict, analyst_name: str = None) -> list:
        """基于统计数据生成调整建议"""
        suggestions = []

        # 命中率偏低
        if stats["hit_rate"] < 0.45 and stats["tracked_count"] >= 5:
            suggestions.append(
                f"近期命中率({stats['hit_rate']:.0%})偏低, 建议提高选股标准, "
                f"优先关注资金面和技术面双重确认的标的"
            )

        # 平均亏损
        if stats["avg_return_pct"] < -2.0:
            suggestions.append(
                "近期平均收益为负, 建议加强风险控制, "
                "适当下调目标价或提高止损要求"
            )

        # 夏普比率
        if stats["sharpe_ratio"] < 0 and stats["tracked_count"] >= 5:
            suggestions.append(
                "夏普比率为负, 收益波动大于平均收益, "
                "建议增加分散度或缩短持仓周期"
            )

        # 板块建议
        by_sector = stats.get("by_sector", {})
        for sector, s in by_sector.items():
            if s["count"] >= 3 and s["hit_rate"] < 0.3:
                suggestions.append(
                    f"{sector}板块近期命中率仅{s['hit_rate']:.0%}, 建议谨慎推荐或降低仓位"
                )
            elif s["count"] >= 3 and s["hit_rate"] > 0.7:
                suggestions.append(
                    f"{sector}板块近期表现优异(命中率{s['hit_rate']:.0%}), 可适当增加关注"
                )

        # 分析师维度建议
        if analyst_name:
            by_analyst = stats.get("by_analyst", {})
            dim_stats = by_analyst.get(analyst_name, {})
            for rating, s in dim_stats.items():
                if s["count"] >= 3 and s["hit_rate"] < 0.3:
                    suggestions.append(
                        f"本维度'{rating}'评级命中率仅{s['hit_rate']:.0%}, "
                        f"建议对此评级的标的更加谨慎"
                    )
                elif s["count"] >= 3 and s["hit_rate"] > 0.7:
                    suggestions.append(
                        f"本维度'{rating}'评级准确度高({s['hit_rate']:.0%}), "
                        f"可适当提升该评级标的的决策权重"
                    )

        # 置信度校准建议
        by_conf = stats.get("by_confidence", {})
        high_conf = by_conf.get("high", {})
        low_conf = by_conf.get("low", {})
        if (
            high_conf.get("count", 0) >= 3
            and low_conf.get("count", 0) >= 3
            and high_conf.get("hit_rate", 0) < low_conf.get("hit_rate", 0)
        ):
            suggestions.append(
                "高置信度标的命中率反低于低置信度, 存在过自信问题, "
                "建议校准置信度计算逻辑"
            )

        return suggestions

    def inject_into_state(self, state: dict) -> dict:
        """将反馈上下文注入到图状态中

        在 create_initial_state 之后调用, 将反馈文本存入 state["feedback_context"],
        供各分析师节点读取并追加到 System Prompt。

        Args:
            state: 图状态字典

        Returns:
            更新后的 state (新增 feedback_context 字段)
        """
        if not self.enabled:
            state["feedback_context"] = {}
            return state

        feedback_map = {}
        # 通用反馈 (所有分析师共享)
        general_feedback = self.generate_feedback_context(analyst_name=None)
        feedback_map["general"] = general_feedback

        # 各分析师维度的专属反馈
        for analyst_name in [
            "fundamentals",
            "technical",
            "china_specific",
            "stock_development",
        ]:
            feedback_map[analyst_name] = self.generate_feedback_context(
                analyst_name=analyst_name
            )

        state["feedback_context"] = feedback_map
        logger.info(
            f"[反馈] 注入完成: general + {len(feedback_map)-1} 个分析师维度"
        )
        return state

    def get_feedback_for_prompt(self, state: dict, analyst_name: str = None) -> str:
        """从状态中获取反馈文本 (供分析师节点使用)

        Args:
            state: 图状态字典
            analyst_name: 分析师名称

        Returns:
            反馈文本 (如无则返回空字符串)
        """
        feedback_map = state.get("feedback_context", {})
        if not feedback_map:
            return ""

        # 优先返回分析师专属反馈, 回退到通用反馈
        if analyst_name and analyst_name in feedback_map:
            return feedback_map[analyst_name]
        return feedback_map.get("general", "")


def get_feedback_from_config(config: dict, analyst_name: str) -> str:
    """从 config 中提取反馈文本 (供分析师函数使用, 无需实例化)

    分析师函数接收 config 参数, 此函数从中提取对应的反馈上下文。

    Args:
        config: 系统配置 (可能含 _feedback_context 字段)
        analyst_name: 分析师名称

    Returns:
        反馈文本 (如无则返回空字符串)
    """
    feedback_map = config.get("_feedback_context", {}) if config else {}
    if not feedback_map:
        return ""
    # 优先返回分析师专属反馈, 回退到通用反馈
    if analyst_name in feedback_map and feedback_map[analyst_name]:
        return feedback_map[analyst_name]
    return feedback_map.get("general", "")
