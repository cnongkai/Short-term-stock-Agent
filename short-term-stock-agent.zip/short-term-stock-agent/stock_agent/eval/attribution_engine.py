"""
多维归因分析引擎 (V3 新增, 对应升级方案阶段三)

对历史推荐结果进行多维归因分析, 识别:
  1. 分析师维度: 哪个分析师维度的评级对最终收益贡献最大/最小
  2. 板块维度: 哪些板块推荐准确率高/低
  3. 置信度维度: 置信度与实际收益的校准度
  4. 工具维度: ReAct 工具调用次数与分析质量的关系
  5. 市场环境维度: 不同市场环境 (牛/熊/震荡) 下的表现差异
  6. 评级组合维度: 四维评级组合对收益的预测力

归因结果供 param_optimizer 使用, 驱动参数自动调优。

使用方式:
    from stock_agent.eval.attribution_engine import AttributionEngine
    engine = AttributionEngine(config)
    report = engine.run_full_attribution(lookback_days=60)
    # report 含各维度归因分析结果 + 优化建议
"""
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from collections import defaultdict
from loguru import logger

from stock_agent.eval.performance_db import PerformanceDB


class AttributionEngine:
    """多维归因分析引擎

    从 PerformanceDB 读取历史推荐与追踪结果, 进行多维度归因分析,
    识别贡献因子与失败模式, 生成优化建议。
    """

    # 分析师维度 → 数据库列名映射
    ANALYST_DIMENSIONS = {
        "fundamentals": "fundamentals_rating",
        "technical": "technical_rating",
        "china_specific": "china_specific_rating",
        "stock_development": "stock_development_rating",
    }

    # 评级 → 数值化映射 (用于相关性分析)
    RATING_SCORE = {
        "看多": 1.0, "买入": 1.0, "强催化": 1.0,
        "中性": 0.0, "持有": 0.0, "中等催化": 0.5,
        "看空": -1.0, "卖出": -1.0, "负催化": -1.0,
        "弱催化": 0.3, "无催化": 0.0,
    }

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.db = PerformanceDB(db_path=self.config.get("performance_db_path"))
        self.min_sample_size = int(self.config.get("attribution_min_sample", 5))

    def run_full_attribution(self, lookback_days: int = 60) -> dict:
        """执行全维度归因分析

        Args:
            lookback_days: 回看天数

        Returns:
            归因报告 dict, 含各维度分析结果与优化建议
        """
        logger.info(f"[归因] 开始归因分析 (回看{lookback_days}天)")

        # 获取性能摘要 (含按板块/分析师/置信度分组)
        stats = self.db.get_performance_summary(lookback_days=lookback_days)

        if stats["tracked_count"] < self.min_sample_size:
            logger.warning(
                f"[归因] 追踪样本不足 ({stats['tracked_count']}<{self.min_sample_size}), "
                f"归因结果可能不可靠"
            )

        report = {
            "generated_at": datetime.now().isoformat(),
            "lookback_days": lookback_days,
            "sample_size": stats["tracked_count"],
            "overall": {
                "hit_rate": stats["hit_rate"],
                "avg_return_pct": stats["avg_return_pct"],
                "sharpe_ratio": stats["sharpe_ratio"],
                "max_drawdown_pct": stats["max_drawdown_pct"],
                "avg_excess_return_pct": stats.get("avg_excess_return_pct", 0),
            },
            "analyst_attribution": self._attribute_by_analyst(stats),
            "sector_attribution": self._attribute_by_sector(stats),
            "confidence_calibration": self._attribute_by_confidence(stats),
            "rating_combination_analysis": self._analyze_rating_combinations(),
            "market_regime_analysis": self._analyze_market_regimes(),
            "failure_patterns": stats.get("failure_patterns", []),
            "optimization_suggestions": [],
        }

        # 生成综合优化建议
        report["optimization_suggestions"] = self._generate_optimization_suggestions(report)

        logger.info(
            f"[归因] 分析完成: 样本={report['sample_size']}, "
            f"命中率={report['overall']['hit_rate']:.1%}, "
            f"建议数={len(report['optimization_suggestions'])}"
        )
        return report

    def _attribute_by_analyst(self, stats: dict) -> dict:
        """分析师维度归因

        分析各分析师维度的评级对最终收益的预测力。
        """
        by_analyst = stats.get("by_analyst", {})
        result = {}

        for dim_name, dim_stats in by_analyst.items():
            if not dim_stats:
                result[dim_name] = {"status": "no_data"}
                continue

            # 计算各评级的准确度
            ratings_analysis = {}
            total_correct = 0
            total_count = 0

            for rating, s in dim_stats.items():
                cnt = s.get("count", 0)
                hit_rate = s.get("hit_rate", 0)
                avg_ret = s.get("avg_return", 0)

                # 判断该评级是否"正确"
                # 看多/买入/强催化 → 应该盈利
                # 看空/卖出/负催化 → 应该亏损 (或至少不推荐)
                # 中性 → 不确定
                expected_positive = rating in ("看多", "买入", "强催化")
                expected_negative = rating in ("看空", "卖出", "负催化")

                correct = False
                if expected_positive and avg_ret > 0:
                    correct = True
                elif expected_negative and avg_ret < 0:
                    correct = True
                elif rating in ("中性", "持有", "无催化", "弱催化", "中等催化"):
                    correct = True  # 中性评级不评判对错

                if correct:
                    total_correct += cnt
                total_count += cnt

                ratings_analysis[rating] = {
                    "count": cnt,
                    "hit_rate": hit_rate,
                    "avg_return": avg_ret,
                    "expected_positive": expected_positive,
                    "expected_negative": expected_negative,
                    "prediction_correct": correct,
                }

            # 计算该维度的整体预测准确度
            prediction_accuracy = total_correct / total_count if total_count > 0 else 0

            # 识别该维度的强信号和弱信号
            strong_signals = [
                r for r, a in ratings_analysis.items()
                if a["count"] >= 3 and a["prediction_correct"] and a["avg_return"] != 0
            ]
            weak_signals = [
                r for r, a in ratings_analysis.items()
                if a["count"] >= 3 and not a["prediction_correct"]
            ]

            result[dim_name] = {
                "prediction_accuracy": prediction_accuracy,
                "ratings": ratings_analysis,
                "strong_signals": strong_signals,
                "weak_signals": weak_signals,
                "contribution_score": self._calc_contribution_score(ratings_analysis),
            }

        return result

    def _calc_contribution_score(self, ratings_analysis: dict) -> float:
        """计算分析师维度的贡献分 (0-1)

        贡献分 = 预测准确度 × 样本覆盖度
        """
        total_count = sum(r["count"] for r in ratings_analysis.values())
        if total_count == 0:
            return 0.0

        correct_count = sum(
            r["count"] for r in ratings_analysis.values() if r["prediction_correct"]
        )
        accuracy = correct_count / total_count
        # 样本覆盖度: 至少 10 个样本才满分
        coverage = min(1.0, total_count / 10)

        return round(accuracy * coverage, 3)

    def _attribute_by_sector(self, stats: dict) -> dict:
        """板块维度归因"""
        by_sector = stats.get("by_sector", {})
        if not by_sector:
            return {"status": "no_data"}

        result = {
            "best_sectors": [],
            "worst_sectors": [],
            "all_sectors": {},
        }

        sorted_sectors = sorted(
            by_sector.items(),
            key=lambda x: x[1].get("avg_return", 0),
            reverse=True,
        )

        for sector, s in sorted_sectors:
            entry = {
                "sector": sector,
                "count": s.get("count", 0),
                "hit_rate": s.get("hit_rate", 0),
                "avg_return": s.get("avg_return", 0),
            }
            result["all_sectors"][sector] = entry
            if s.get("count", 0) >= 3 and s.get("avg_return", 0) > 0:
                result["best_sectors"].append(entry)
            elif s.get("count", 0) >= 3 and s.get("avg_return", 0) < 0:
                result["worst_sectors"].append(entry)

        return result

    def _attribute_by_confidence(self, stats: dict) -> dict:
        """置信度校准分析

        检验置信度与实际收益的相关性。
        """
        by_conf = stats.get("by_confidence", {})
        if not by_conf:
            return {"status": "no_data"}

        result = {
            "calibration_status": "unknown",
            "buckets": {},
            "is_well_calibrated": False,
        }

        for bucket in ["high", "medium", "low"]:
            s = by_conf.get(bucket, {})
            if not s:
                continue
            threshold = {"high": 0.7, "medium": 0.5, "low": 0.0}
            result["buckets"][bucket] = {
                "count": s.get("count", 0),
                "hit_rate": s.get("hit_rate", 0),
                "avg_return": s.get("avg_return", 0),
                "confidence_range": f">={threshold[bucket]}" if bucket != "low" else "<0.5",
            }

        # 校准检验: 高置信度命中率应 > 低置信度命中率
        high_hr = by_conf.get("high", {}).get("hit_rate", 0)
        low_hr = by_conf.get("low", {}).get("hit_rate", 0)
        high_cnt = by_conf.get("high", {}).get("count", 0)
        low_cnt = by_conf.get("low", {}).get("count", 0)

        if high_cnt >= 3 and low_cnt >= 3:
            if high_hr > low_hr:
                result["calibration_status"] = "well_calibrated"
                result["is_well_calibrated"] = True
            elif high_hr < low_hr:
                result["calibration_status"] = "overconfident"
            else:
                result["calibration_status"] = "uncalibrated"
        else:
            result["calibration_status"] = "insufficient_data"

        return result

    def _analyze_rating_combinations(self) -> dict:
        """分析四维评级组合对收益的预测力

        将推荐标的按四维评级组合分组, 分析不同组合的收益差异。
        """
        try:
            conn = self.db._get_conn()
            cursor = conn.cursor()

            # 查询所有已追踪的推荐 (含四维评级)
            cursor.execute(
                """
                SELECT r.ticker, r.trade_date,
                       r.fundamentals_rating, r.technical_rating,
                       r.china_specific_rating, r.stock_development_rating,
                       r.confidence, r.sector,
                       o.return_pct, o.outcome, o.holding_days
                FROM recommendations r
                JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
                WHERE o.return_pct IS NOT NULL
                ORDER BY r.trade_date DESC
                LIMIT 200
                """
            )
            rows = [dict(row) for row in cursor.fetchall()]

            if len(rows) < self.min_sample_size:
                return {"status": "insufficient_data", "sample_count": len(rows)}

            # 按评级组合分组
            combo_stats = defaultdict(lambda: {"count": 0, "total_return": 0, "hits": 0})

            for row in rows:
                # 简化组合: 看多/买入=+, 看空/卖出=-, 中性=0
                combo_parts = []
                for dim_col in ["fundamentals_rating", "technical_rating",
                                "china_specific_rating", "stock_development_rating"]:
                    rating = row.get(dim_col, "")
                    if rating in ("看多", "买入", "强催化"):
                        combo_parts.append("+")
                    elif rating in ("看空", "卖出", "负催化"):
                        combo_parts.append("-")
                    else:
                        combo_parts.append("0")

                combo_key = "/".join(combo_parts)
                ret = row.get("return_pct", 0) or 0
                combo_stats[combo_key]["count"] += 1
                combo_stats[combo_key]["total_return"] += ret
                if ret > 0:
                    combo_stats[combo_key]["hits"] += 1

            # 计算各组合的平均收益和命中率
            combo_analysis = {}
            for combo, s in sorted(combo_stats.items(),
                                    key=lambda x: x[1]["total_return"] / x[1]["count"],
                                    reverse=True):
                cnt = s["count"]
                combo_analysis[combo] = {
                    "count": cnt,
                    "avg_return": round(s["total_return"] / cnt, 2) if cnt > 0 else 0,
                    "hit_rate": round(s["hits"] / cnt, 2) if cnt > 0 else 0,
                }

            # 识别最优/最差组合
            best_combo = max(combo_analysis.items(),
                            key=lambda x: x[1]["avg_return"]) if combo_analysis else None
            worst_combo = min(combo_analysis.items(),
                             key=lambda x: x[1]["avg_return"]) if combo_analysis else None

            return {
                "status": "ok",
                "sample_count": len(rows),
                "combinations": combo_analysis,
                "best_combination": {
                    "pattern": best_combo[0],
                    **best_combo[1],
                } if best_combo else None,
                "worst_combination": {
                    "pattern": worst_combo[0],
                    **worst_combo[1],
                } if worst_combo else None,
            }

        except Exception as e:
            logger.error(f"[归因] 评级组合分析失败: {e}")
            return {"status": "error", "error": str(e)}

    def _analyze_market_regimes(self) -> dict:
        """分析不同市场环境下的表现"""
        try:
            conn = self.db._get_conn()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT market_regime,
                       COUNT(*) as count,
                       AVG(hit_rate) as avg_hit_rate,
                       AVG(avg_return_pct) as avg_return,
                       AVG(sharpe_ratio) as avg_sharpe,
                       AVG(max_drawdown_pct) as avg_max_dd
                FROM run_stats
                WHERE market_regime IS NOT NULL AND market_regime != ''
                GROUP BY market_regime
                """
            )
            rows = [dict(row) for row in cursor.fetchall()]

            if not rows:
                return {"status": "no_data"}

            result = {}
            for row in rows:
                regime = row["market_regime"]
                result[regime] = {
                    "run_count": row["count"],
                    "avg_hit_rate": row["avg_hit_rate"] or 0,
                    "avg_return": row["avg_return"] or 0,
                    "avg_sharpe": row["avg_sharpe"] or 0,
                    "avg_max_drawdown": row["avg_max_dd"] or 0,
                }

            return {"status": "ok", "regimes": result}

        except Exception as e:
            logger.error(f"[归因] 市场环境分析失败: {e}")
            return {"status": "error", "error": str(e)}

    def _generate_optimization_suggestions(self, report: dict) -> list:
        """基于归因结果生成优化建议"""
        suggestions = []

        # === 分析师维度建议 ===
        analyst_attr = report.get("analyst_attribution", {})
        for dim_name, attr in analyst_attr.items():
            if not isinstance(attr, dict) or attr.get("status") == "no_data":
                continue

            contribution = attr.get("contribution_score", 0)
            weak_signals = attr.get("weak_signals", [])

            if contribution < 0.3 and attr.get("prediction_accuracy", 0) < 0.4:
                suggestions.append({
                    "type": "analyst_weight",
                    "target": dim_name,
                    "action": "decrease_weight",
                    "reason": f"维度'{dim_name}'预测准确度仅{attr.get('prediction_accuracy', 0):.0%},"
                              f"贡献分{contribution:.2f}, 建议降低该维度在决策中的权重",
                    "priority": "high",
                })
            elif contribution > 0.7:
                suggestions.append({
                    "type": "analyst_weight",
                    "target": dim_name,
                    "action": "increase_weight",
                    "reason": f"维度'{dim_name}'预测准确度{attr.get('prediction_accuracy', 0):.0%},"
                              f"贡献分{contribution:.2f}, 建议提升该维度在决策中的权重",
                    "priority": "medium",
                })

            for weak_rating in weak_signals:
                suggestions.append({
                    "type": "rating_adjustment",
                    "target": f"{dim_name}.{weak_rating}",
                    "action": "review",
                    "reason": f"维度'{dim_name}'的'{weak_rating}'评级预测方向与实际收益不一致,"
                              f"建议检查该评级的判断逻辑",
                    "priority": "medium",
                })

        # === 板块维度建议 ===
        sector_attr = report.get("sector_attribution", {})
        worst_sectors = sector_attr.get("worst_sectors", [])
        best_sectors = sector_attr.get("best_sectors", [])

        for s in worst_sectors:
            suggestions.append({
                "type": "sector_filter",
                "target": s["sector"],
                "action": "tighten_filter",
                "reason": f"板块'{s['sector']}'近期命中率{s['hit_rate']:.0%},"
                          f"平均收益{s['avg_return']:+.2f}%, 建议提高该板块选股门槛或降低仓位",
                "priority": "high",
            })

        for s in best_sectors:
            suggestions.append({
                "type": "sector_filter",
                "target": s["sector"],
                "action": "relax_filter",
                "reason": f"板块'{s['sector']}'近期命中率{s['hit_rate']:.0%},"
                          f"平均收益{s['avg_return']:+.2f}%, 可适当增加该板块关注",
                "priority": "low",
            })

        # === 置信度校准建议 ===
        conf_cal = report.get("confidence_calibration", {})
        if conf_cal.get("calibration_status") == "overconfident":
            suggestions.append({
                "type": "confidence_calibration",
                "target": "confidence_calculation",
                "action": "recalibrate",
                "reason": "高置信度标的命中率反低于低置信度, 存在过自信问题,"
                          "建议校准置信度计算逻辑或增加惩罚项",
                "priority": "high",
            })

        # === 评级组合建议 ===
        combo_analysis = report.get("rating_combination_analysis", {})
        if combo_analysis.get("status") == "ok":
            best = combo_analysis.get("best_combination")
            worst = combo_analysis.get("worst_combination")
            if best and best.get("count", 0) >= 3:
                suggestions.append({
                    "type": "rating_combination",
                    "target": best["pattern"],
                    "action": "prioritize",
                    "reason": f"评级组合'{best['pattern']}'表现最佳"
                              f"(平均收益{best['avg_return']:+.2f}%, 命中率{best['hit_rate']:.0%}),"
                              f"建议在决策中优先考虑此组合",
                    "priority": "medium",
                })
            if worst and worst.get("count", 0) >= 3:
                suggestions.append({
                    "type": "rating_combination",
                    "target": worst["pattern"],
                    "action": "deprioritize",
                    "reason": f"评级组合'{worst['pattern']}'表现最差"
                              f"(平均收益{worst['avg_return']:+.2f}%, 命中率{worst['hit_rate']:.0%}),"
                              f"建议在决策中对此组合保持谨慎",
                    "priority": "medium",
                })

        # === 整体表现建议 ===
        overall = report.get("overall", {})
        if overall.get("hit_rate", 0) < 0.4 and report.get("sample_size", 0) >= 10:
            suggestions.append({
                "type": "global",
                "target": "selection_threshold",
                "action": "tighten",
                "reason": f"整体命中率{overall['hit_rate']:.0%}偏低, "
                          f"建议提高选股阈值 (dark_horse_score_threshold / sector_top_n)",
                "priority": "high",
            })

        if overall.get("max_drawdown_pct", 0) < -5.0:
            suggestions.append({
                "type": "global",
                "target": "risk_control",
                "action": "tighten_stop_loss",
                "reason": f"最大回撤{overall['max_drawdown_pct']:.2f}%偏大, "
                          f"建议收紧止损线或降低单标的仓位",
                "priority": "high",
            })

        # 按优先级排序
        priority_order = {"high": 0, "medium": 1, "low": 2}
        suggestions.sort(key=lambda x: priority_order.get(x.get("priority", "low"), 2))

        return suggestions

    def generate_attribution_report_text(self, report: dict = None) -> str:
        """生成归因分析文本报告 (可追加到验证报告)"""
        if report is None:
            report = self.run_full_attribution()

        lines = []
        lines.append("### 8. 多维归因分析")
        lines.append("")
        lines.append(f"> 样本量: {report['sample_size']} | "
                     f"回看: {report['lookback_days']}天 | "
                     f"生成时间: {report['generated_at'][:19]}")
        lines.append("")

        # 整体表现
        overall = report.get("overall", {})
        lines.append("#### 整体表现")
        lines.append(f"- 命中率: {overall.get('hit_rate', 0):.1%}")
        lines.append(f"- 平均收益: {overall.get('avg_return_pct', 0):+.2f}%")
        lines.append(f"- 夏普比率: {overall.get('sharpe_ratio', 0):.2f}")
        lines.append(f"- 最大回撤: {overall.get('max_drawdown_pct', 0):.2f}%")
        lines.append(f"- 超额收益: {overall.get('avg_excess_return_pct', 0):+.2f}%")
        lines.append("")

        # 分析师维度
        analyst_attr = report.get("analyst_attribution", {})
        if analyst_attr:
            lines.append("#### 分析师维度归因")
            lines.append("| 维度 | 预测准确度 | 贡献分 | 强信号 | 弱信号 |")
            lines.append("|------|-----------|--------|--------|--------|")
            for dim, attr in analyst_attr.items():
                if attr.get("status") == "no_data":
                    lines.append(f"| {dim} | - | - | - | - |")
                    continue
                lines.append(
                    f"| {dim} | {attr.get('prediction_accuracy', 0):.0%} | "
                    f"{attr.get('contribution_score', 0):.2f} | "
                    f"{', '.join(attr.get('strong_signals', [])) or '-'} | "
                    f"{', '.join(attr.get('weak_signals', [])) or '-'} |"
                )
            lines.append("")

        # 板块维度
        sector_attr = report.get("sector_attribution", {})
        if sector_attr.get("all_sectors"):
            lines.append("#### 板块维度归因 (Top 5)")
            lines.append("| 板块 | 样本数 | 命中率 | 平均收益 |")
            lines.append("|------|--------|--------|---------|")
            sorted_sectors = sorted(
                sector_attr["all_sectors"].items(),
                key=lambda x: x[1].get("avg_return", 0),
                reverse=True,
            )[:5]
            for sector, s in sorted_sectors:
                lines.append(
                    f"| {sector} | {s['count']} | "
                    f"{s['hit_rate']:.0%} | {s['avg_return']:+.2f}% |"
                )
            lines.append("")

        # 置信度校准
        conf_cal = report.get("confidence_calibration", {})
        if conf_cal.get("buckets"):
            lines.append("#### 置信度校准")
            lines.append(f"- 校准状态: {conf_cal.get('calibration_status', 'unknown')}")
            lines.append("| 区间 | 样本数 | 命中率 | 平均收益 |")
            lines.append("|------|--------|--------|---------|")
            for bucket in ["high", "medium", "low"]:
                s = conf_cal["buckets"].get(bucket, {})
                if s:
                    lines.append(
                        f"| {bucket}({s.get('confidence_range', '')}) | "
                        f"{s.get('count', 0)} | {s.get('hit_rate', 0):.0%} | "
                        f"{s.get('avg_return', 0):+.2f}% |"
                    )
            lines.append("")

        # 优化建议
        suggestions = report.get("optimization_suggestions", [])
        if suggestions:
            lines.append("#### 优化建议")
            for i, s in enumerate(suggestions, 1):
                lines.append(
                    f"{i}. [{s.get('priority', 'low').upper()}] "
                    f"{s.get('type', '')} → {s.get('action', '')}: "
                    f"{s.get('reason', '')}"
                )
            lines.append("")

        return "\n".join(lines)
