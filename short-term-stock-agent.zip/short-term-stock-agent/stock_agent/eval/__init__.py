"""
评估与反馈模块 (V3 新增, 对应升级方案阶段一~四)

提供推荐结果追踪、性能持久化、Prompt 反馈注入、归因分析与参数调优能力,
将"一次性推荐系统"升级为"自学习推荐系统"。

模块组成:
  - performance_db:     性能数据库 (SQLite), 持久化推荐与结果
  - outcome_tracker:    T+N 结果追踪器, 获取推荐后真实涨跌
  - feedback_injector:  Prompt 反馈注入器, 将历史表现摘要注入分析师 Prompt
  - attribution_engine: 多维归因分析 (分析师/板块/置信度/工具/市场环境)
  - param_optimizer:    参数自动调优 (板块权重/ReAct迭代/选股阈值)
  - backtest_runner:    批量回测调度器 (历史日期重放 + 结果聚合)
"""
