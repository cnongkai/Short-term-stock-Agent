"""
参数自动调优器 (V3 新增, 对应升级方案阶段三)

基于 AttributionEngine 的归因分析结果, 自动生成参数调优建议并输出
优化后的配置覆盖项, 支持:
  1. 板块权重调优: 根据各板块历史命中率调整 sector_metric_weights
  2. ReAct 迭代调优: 根据分析质量与迭代次数关系调整 react_max_iterations
  3. 选股阈值调优: 根据 overall hit_rate 调整 dark_horse_score_threshold / sector_top_n
  4. 置信度校准: 根据校准状态调整置信度计算参数
  5. 分析师权重调优: 根据各维度贡献分调整决策权重

调优策略: 保守增量调整 (每次调整幅度 ≤20%), 避免剧烈参数变动。

使用方式:
    from stock_agent.eval.param_optimizer import ParamOptimizer
    optimizer = ParamOptimizer(config)
    optimized = optimizer.optimize(lookback_days=60)
    # optimized 含建议的参数覆盖项 + 调整说明
"""
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any
from copy import deepcopy
from loguru import logger

from stock_agent.eval.attribution_engine import AttributionEngine


class ParamOptimizer:
    """参数自动调优器

    基于归因分析结果, 生成保守的参数调整建议。
    """

    # 最大单次调整幅度 (20%)
    MAX_ADJUSTMENT_RATIO = 0.20
    # 最小样本量 (低于此值不调优)
    MIN_SAMPLE_FOR_OPTIMIZE = 10

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.engine = AttributionEngine(config)
        self.optimization_history_path = self.config.get(
            "optimization_history_path",
            os.path.join(
                self.config.get("results_dir", "./results"),
                "optimization_history.json"
            ),
        )

    def optimize(self, lookback_days: int = 60, dry_run: bool = True) -> dict:
        """执行参数调优

        Args:
            lookback_days: 回看天数
            dry_run: True 仅生成建议不应用; False 写入历史记录

        Returns:
            {
                "timestamp": str,
                "sample_size": int,
                "current_config": dict,       # 当前配置快照
                "suggested_overrides": dict,   # 建议的配置覆盖项
                "adjustments": list,           # 调整说明列表
                "applied": bool,               # 是否已应用
            }
        """
        logger.info(f"[调优] 开始参数调优 (回看{lookback_days}天, dry_run={dry_run})")

        # 执行归因分析
        attribution_report = self.engine.run_full_attribution(lookback_days=lookback_days)

        if attribution_report["sample_size"] < self.MIN_SAMPLE_FOR_OPTIMIZE:
            logger.warning(
                f"[调优] 样本不足 ({attribution_report['sample_size']}"
                f"<{self.MIN_SAMPLE_FOR_OPTIMIZE}), 跳过调优"
            )
            return {
                "timestamp": datetime.now().isoformat(),
                "sample_size": attribution_report["sample_size"],
                "status": "skipped_insufficient_data",
                "suggested_overrides": {},
                "adjustments": [],
            }

        # 生成各维度调优建议
        adjustments = []
        suggested_overrides = {}

        # 1. 选股阈值调优
        threshold_adj = self._optimize_selection_threshold(attribution_report)
        if threshold_adj:
            adjustments.extend(threshold_adj["adjustments"])
            suggested_overrides.update(threshold_adj["overrides"])

        # 2. 板块权重调优
        sector_adj = self._optimize_sector_weights(attribution_report)
        if sector_adj:
            adjustments.extend(sector_adj["adjustments"])
            suggested_overrides.update(sector_adj["overrides"])

        # 3. ReAct 迭代调优
        react_adj = self._optimize_react_iterations(attribution_report)
        if react_adj:
            adjustments.extend(react_adj["adjustments"])
            suggested_overrides.update(react_adj["overrides"])

        # 4. 置信度校准调优
        conf_adj = self._optimize_confidence_calibration(attribution_report)
        if conf_adj:
            adjustments.extend(conf_adj["adjustments"])
            suggested_overrides.update(conf_adj["overrides"])

        # 5. 分析师维度权重调优
        analyst_adj = self._optimize_analyst_weights(attribution_report)
        if analyst_adj:
            adjustments.extend(analyst_adj["adjustments"])
            suggested_overrides.update(analyst_adj["overrides"])

        result = {
            "timestamp": datetime.now().isoformat(),
            "sample_size": attribution_report["sample_size"],
            "lookback_days": lookback_days,
            "overall_hit_rate": attribution_report["overall"]["hit_rate"],
            "overall_avg_return": attribution_report["overall"]["avg_return_pct"],
            "suggested_overrides": suggested_overrides,
            "adjustments": adjustments,
            "attribution_summary": {
                "analyst_attribution": {
                    dim: {
                        "prediction_accuracy": attr.get("prediction_accuracy", 0),
                        "contribution_score": attr.get("contribution_score", 0),
                    }
                    for dim, attr in attribution_report.get("analyst_attribution", {}).items()
                    if isinstance(attr, dict) and attr.get("status") != "no_data"
                },
                "confidence_calibration": attribution_report.get(
                    "confidence_calibration", {}
                ).get("calibration_status", "unknown"),
            },
            "applied": False,
        }

        # 写入历史记录
        if not dry_run:
            self._save_optimization_history(result)
            result["applied"] = True
            logger.info(f"[调优] 参数已应用并记录到 {self.optimization_history_path}")
        else:
            logger.info(
                f"[调优] 生成 {len(adjustments)} 项调优建议 (dry_run, 未应用)"
            )

        return result

    def _optimize_selection_threshold(self, report: dict) -> Optional[dict]:
        """选股阈值调优"""
        overall = report.get("overall", {})
        hit_rate = overall.get("hit_rate", 0)
        sample_size = report.get("sample_size", 0)

        if sample_size < self.MIN_SAMPLE_FOR_OPTIMIZE:
            return None

        adjustments = []
        overrides = {}

        # 命中率偏低 → 提高阈值
        if hit_rate < 0.40:
            current_threshold = self.config.get("dark_horse_score_threshold", 60)
            new_threshold = min(80, int(current_threshold * (1 + self.MAX_ADJUSTMENT_RATIO)))
            adjustments.append({
                "type": "selection_threshold",
                "param": "dark_horse_score_threshold",
                "old_value": current_threshold,
                "new_value": new_threshold,
                "reason": f"命中率{hit_rate:.0%}偏低, 提高黑马评分阈值"
                          f"({current_threshold}→{new_threshold})以过滤低质量标的",
            })
            overrides["dark_horse_score_threshold"] = new_threshold

            # 同时减少 sector_top_n
            current_top_n = self.config.get("sector_top_n", 5)
            new_top_n = max(3, int(current_top_n * (1 - self.MAX_ADJUSTMENT_RATIO)))
            adjustments.append({
                "type": "selection_threshold",
                "param": "sector_top_n",
                "old_value": current_top_n,
                "new_value": new_top_n,
                "reason": f"命中率偏低, 减少每板块选股数"
                          f"({current_top_n}→{new_top_n})以提高整体质量",
            })
            overrides["sector_top_n"] = new_top_n

        # 命中率很高 → 可适当放宽
        elif hit_rate > 0.65 and sample_size >= 20:
            current_threshold = self.config.get("dark_horse_score_threshold", 60)
            new_threshold = max(40, int(current_threshold * (1 - self.MAX_ADJUSTMENT_RATIO * 0.5)))
            adjustments.append({
                "type": "selection_threshold",
                "param": "dark_horse_score_threshold",
                "old_value": current_threshold,
                "new_value": new_threshold,
                "reason": f"命中率{hit_rate:.0%}较高, 适当降低阈值"
                          f"({current_threshold}→{new_threshold})以扩大候选池",
            })
            overrides["dark_horse_score_threshold"] = new_threshold

        if adjustments:
            return {"adjustments": adjustments, "overrides": overrides}
        return None

    def _optimize_sector_weights(self, report: dict) -> Optional[dict]:
        """板块五维指标权重调优"""
        sector_attr = report.get("sector_attribution", {})
        all_sectors = sector_attr.get("all_sectors", {})

        if len(all_sectors) < 3:
            return None

        adjustments = []
        overrides = {}

        # 获取当前权重
        current_weights = self.config.get("sector_metric_weights", {
            "heat": 0.25, "diffusion": 0.20, "volatility": 0.15,
            "rebound": 0.20, "crowding": 0.20,
        })

        # 分析: 如果高命中率板块集中在某些特征, 可以提升对应权重
        # 简化: 根据整体表现微调 crowding 权重
        overall = report.get("overall", {})
        max_dd = overall.get("max_drawdown_pct", 0)

        new_weights = dict(current_weights)

        # 最大回撤偏大 → 增加 crowding 权重 (更注重拥挤度以规避风险)
        if max_dd < -5.0:
            old_crowding = current_weights.get("crowding", 0.20)
            new_crowding = round(min(0.35, old_crowding * (1 + self.MAX_ADJUSTMENT_RATIO)), 2)
            diff = new_crowding - old_crowding
            # 从 heat 中扣除
            old_heat = current_weights.get("heat", 0.25)
            new_heat = round(max(0.10, old_heat - diff), 2)

            new_weights["crowding"] = new_crowding
            new_weights["heat"] = new_heat

            adjustments.append({
                "type": "sector_weights",
                "param": "sector_metric_weights",
                "old_value": current_weights,
                "new_value": new_weights,
                "reason": f"最大回撤{max_dd:.2f}%偏大, 提升拥挤度权重"
                          f"(crowding: {old_crowding}→{new_crowding})"
                          f"以增强风险规避",
            })
            overrides["sector_metric_weights"] = new_weights

        if adjustments:
            return {"adjustments": adjustments, "overrides": overrides}
        return None

    def _optimize_react_iterations(self, report: dict) -> Optional[dict]:
        """ReAct 迭代次数调优"""
        adjustments = []
        overrides = {}

        # 分析各分析师维度的预测准确度
        analyst_attr = report.get("analyst_attribution", {})
        current_per_analyst = self.config.get("react_per_analyst", {})
        new_per_analyst = deepcopy(current_per_analyst)
        changed = False

        for dim_name, attr in analyst_attr.items():
            if not isinstance(attr, dict) or attr.get("status") == "no_data":
                continue

            accuracy = attr.get("prediction_accuracy", 0)
            contribution = attr.get("contribution_score", 0)

            # 贡献分低且准确度低 → 减少迭代 (节省成本)
            if contribution < 0.3 and accuracy < 0.4:
                dim_config = new_per_analyst.get(dim_name, {})
                current_iter = dim_config.get("max_iterations",
                                              self.config.get("react_max_iterations", 5))
                new_iter = max(2, int(current_iter * (1 - self.MAX_ADJUSTMENT_RATIO)))

                if new_iter < current_iter:
                    dim_config["max_iterations"] = new_iter
                    new_per_analyst[dim_name] = dim_config
                    changed = True
                    adjustments.append({
                        "type": "react_iterations",
                        "param": f"react_per_analyst.{dim_name}.max_iterations",
                        "old_value": current_iter,
                        "new_value": new_iter,
                        "reason": f"维度'{dim_name}'准确度{accuracy:.0%}偏低, "
                                  f"减少迭代({current_iter}→{new_iter})以节省成本",
                    })

            # 贡献分高且准确度高 → 可增加迭代
            elif contribution > 0.7 and accuracy > 0.6:
                dim_config = new_per_analyst.get(dim_name, {})
                current_iter = dim_config.get("max_iterations",
                                              self.config.get("react_max_iterations", 5))
                new_iter = min(8, int(current_iter * (1 + self.MAX_ADJUSTMENT_RATIO)))

                if new_iter > current_iter:
                    dim_config["max_iterations"] = new_iter
                    new_per_analyst[dim_name] = dim_config
                    changed = True
                    adjustments.append({
                        "type": "react_iterations",
                        "param": f"react_per_analyst.{dim_name}.max_iterations",
                        "old_value": current_iter,
                        "new_value": new_iter,
                        "reason": f"维度'{dim_name}'准确度{accuracy:.0%}较高, "
                                  f"增加迭代({current_iter}→{new_iter})以提升分析深度",
                    })

        if changed:
            overrides["react_per_analyst"] = new_per_analyst
            return {"adjustments": adjustments, "overrides": overrides}
        return None

    def _optimize_confidence_calibration(self, report: dict) -> Optional[dict]:
        """置信度校准调优"""
        conf_cal = report.get("confidence_calibration", {})
        status = conf_cal.get("calibration_status", "")

        if status != "overconfident":
            return None

        adjustments = []
        overrides = {}

        # 过自信问题: 高置信度命中率反而低
        # 建议: 在决策层增加置信度惩罚因子
        current_penalty = self.config.get("confidence_penalty_factor", 0.0)
        new_penalty = round(min(0.3, current_penalty + 0.1), 2)

        adjustments.append({
            "type": "confidence_calibration",
            "param": "confidence_penalty_factor",
            "old_value": current_penalty,
            "new_value": new_penalty,
            "reason": "高置信度命中率反低于低置信度 (过自信), "
                      f"增加置信度惩罚因子({current_penalty}→{new_penalty})",
        })
        overrides["confidence_penalty_factor"] = new_penalty

        return {"adjustments": adjustments, "overrides": overrides}

    def _optimize_analyst_weights(self, report: dict) -> Optional[dict]:
        """分析师维度权重调优"""
        analyst_attr = report.get("analyst_attribution", {})
        if not analyst_attr:
            return None

        adjustments = []
        overrides = {}

        # 计算各维度贡献分, 生成权重分配
        contributions = {}
        for dim_name, attr in analyst_attr.items():
            if isinstance(attr, dict) and attr.get("status") != "no_data":
                contributions[dim_name] = attr.get("contribution_score", 0)

        if len(contributions) < 2:
            return None

        # 归一化为权重
        total_contribution = sum(contributions.values())
        if total_contribution <= 0:
            return None

        # 均匀分配作为基线, 按贡献分加权
        n = len(contributions)
        base_weight = 1.0 / n
        # 贡献分权重 = 基线 + 贡献分偏移
        suggested_weights = {}
        for dim, contrib in contributions.items():
            # 贡献分偏移: 最大 ±20% 调整
            offset = (contrib / total_contribution - 1.0 / n) * 0.5  # 缩放因子
            offset = max(-self.MAX_ADJUSTMENT_RATIO, min(self.MAX_ADJUSTMENT_RATIO, offset))
            suggested_weights[dim] = round(base_weight * (1 + offset), 3)

        # 归一化确保权重和为 1
        total = sum(suggested_weights.values())
        if total > 0:
            suggested_weights = {k: round(v / total, 3) for k, v in suggested_weights.items()}

        current_weights = self.config.get("analyst_decision_weights", {})
        if current_weights != suggested_weights:
            adjustments.append({
                "type": "analyst_weights",
                "param": "analyst_decision_weights",
                "old_value": current_weights,
                "new_value": suggested_weights,
                "reason": "根据各维度贡献分重新分配决策权重: "
                          + ", ".join(f"{k}={v:.0%}" for k, v in contributions.items()),
            })
            overrides["analyst_decision_weights"] = suggested_weights

        if adjustments:
            return {"adjustments": adjustments, "overrides": overrides}
        return None

    def _save_optimization_history(self, result: dict):
        """保存调优历史记录"""
        try:
            history = []
            if os.path.exists(self.optimization_history_path):
                with open(self.optimization_history_path, "r", encoding="utf-8") as f:
                    history = json.load(f)

            history.append(result)

            os.makedirs(os.path.dirname(self.optimization_history_path), exist_ok=True)
            with open(self.optimization_history_path, "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2, default=str)

            logger.info(f"[调优] 历史记录已保存 ({len(history)} 条)")
        except Exception as e:
            logger.error(f"[调优] 保存历史记录失败: {e}")

    def get_optimization_history(self) -> list:
        """获取调优历史记录"""
        try:
            if os.path.exists(self.optimization_history_path):
                with open(self.optimization_history_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            return []
        except Exception:
            return []

    def generate_optimization_report_text(self, result: dict = None) -> str:
        """生成调优报告文本"""
        if result is None:
            result = self.optimize(dry_run=True)

        lines = []
        lines.append("### 9. 参数调优建议")
        lines.append("")
        lines.append(f"> 样本量: {result.get('sample_size', 0)} | "
                     f"命中率: {result.get('overall_hit_rate', 0):.1%} | "
                     f"平均收益: {result.get('overall_avg_return', 0):+.2f}%")
        lines.append("")

        adjustments = result.get("adjustments", [])
        if not adjustments:
            lines.append("当前参数表现良好, 无需调整。")
            lines.append("")
            return "\n".join(lines)

        lines.append(f"共 {len(adjustments)} 项调优建议:")
        lines.append("")
        lines.append("| # | 类型 | 参数 | 旧值 | 新值 | 原因 |")
        lines.append("|---|------|------|------|------|------|")
        for i, adj in enumerate(adjustments, 1):
            old_val = adj.get("old_value", "")
            new_val = adj.get("new_value", "")
            # 截断过长的值
            if isinstance(old_val, dict):
                old_val = "..."
            if isinstance(new_val, dict):
                new_val = "..."
            lines.append(
                f"| {i} | {adj.get('type', '')} | "
                f"{adj.get('param', '')} | {old_val} | {new_val} | "
                f"{adj.get('reason', '')} |"
            )
        lines.append("")

        # 建议的配置覆盖项
        overrides = result.get("suggested_overrides", {})
        if overrides:
            lines.append("#### 建议的配置覆盖项 (JSON)")
            lines.append("```json")
            lines.append(json.dumps(overrides, ensure_ascii=False, indent=2))
            lines.append("```")
            lines.append("")

        return "\n".join(lines)
