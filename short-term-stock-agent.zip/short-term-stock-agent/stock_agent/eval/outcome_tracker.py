"""
T+N 结果追踪器 (V3 新增, 对应升级方案阶段一)

在每日推荐产出后, 获取推荐标的在 T+1 至 T+N (持仓周期) 的真实收盘价,
计算收益率、是否触及止损/止盈, 将结果写入 PerformanceDB。

追踪逻辑:
  1. 从 PerformanceDB 读取未追踪的推荐记录
  2. 判断推荐日期距今是否已超过持仓周期 (可追踪)
  3. 获取 T+1 ~ T+N 的日线收盘价
  4. 逐日检查: 是否触及止损 (stop_loss) 或止盈 (take_profit)
  5. 计算最终收益率、最大收益、最大回撤
  6. 获取基准 (沪深300) 同期收益, 计算超额收益
  7. 写入 PerformanceDB

使用方式:
    from stock_agent.eval.outcome_tracker import OutcomeTracker
    tracker = OutcomeTracker(config)
    tracker.track_all_pending()  # 追踪所有待追踪推荐
"""
import os
import json
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from loguru import logger

from stock_agent.eval.performance_db import PerformanceDB


class OutcomeTracker:
    """T+N 结果追踪器

    获取推荐标的在持仓周期内的真实价格走势, 计算收益并持久化。
    """

    # 沪深300 ETF 代码 (用于基准对比, 510300 = 华泰柏瑞沪深300ETF)
    BENCHMARK_TICKER = "510300"

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.db = PerformanceDB(
            db_path=self.config.get("performance_db_path")
        )
        self.default_holding_period = self._parse_holding_period(
            self.config.get("default_holding_period", "1-5")
        )

    def _parse_holding_period(self, period_str: str) -> int:
        """解析持仓周期字符串 (如 "1-5" → 5)"""
        try:
            if "-" in period_str:
                parts = period_str.split("-")
                return int(parts[-1])
            return int(period_str)
        except (ValueError, IndexError):
            return 5

    def track_all_pending(self, force_holding_days: int = None) -> dict:
        """追踪所有待追踪的推荐记录

        Args:
            force_holding_days: 强制使用此持仓天数 (用于回测, 覆盖用户配置)

        Returns:
            {"tracked": int, "skipped": int, "failed": int, "details": [...]}
        """
        pending = self.db.get_untracked_recommendations()
        today = datetime.now().strftime("%Y-%m-%d")

        tracked = 0
        skipped = 0
        failed = 0
        details = []

        for rec in pending:
            trade_date = rec["trade_date"]
            ticker = rec["ticker"]

            # 确定持仓天数
            if force_holding_days is not None:
                holding_days = force_holding_days
            else:
                holding_days = self._get_holding_days(rec)

            # 判断是否已过持仓周期 (可追踪)
            days_elapsed = self._calc_trading_days_elapsed(trade_date, today)
            if days_elapsed < holding_days and force_holding_days is None:
                skipped += 1
                details.append({
                    "ticker": ticker,
                    "trade_date": trade_date,
                    "status": "skipped",
                    "reason": f"仅过{days_elapsed}交易日, 需{holding_days}天",
                })
                continue

            # 执行追踪
            try:
                result = self._track_single(rec, holding_days)
                if result:
                    tracked += 1
                    details.append({
                        "ticker": ticker,
                        "trade_date": trade_date,
                        "status": "tracked",
                        "outcome": result["outcome"],
                        "return_pct": result["return_pct"],
                    })
                else:
                    failed += 1
                    details.append({
                        "ticker": ticker,
                        "trade_date": trade_date,
                        "status": "failed",
                        "reason": "数据获取失败",
                    })
            except Exception as e:
                failed += 1
                logger.error(f"[追踪] {ticker} trade_date={trade_date} 失败: {e}")
                details.append({
                    "ticker": ticker,
                    "trade_date": trade_date,
                    "status": "failed",
                    "reason": str(e),
                })

        logger.info(
            f"[追踪] 完成: 追踪 {tracked}, 跳过 {skipped}, 失败 {failed}"
        )
        return {"tracked": tracked, "skipped": skipped, "failed": failed, "details": details}

    def _get_holding_days(self, rec: dict) -> int:
        """从推荐记录中获取持仓天数"""
        period_str = rec.get("user_holding_period", "")
        if period_str:
            days = self._parse_holding_period(period_str)
            if days > 0:
                return days
        return self.default_holding_period

    def _calc_trading_days_elapsed(self, start_date: str, end_date: str) -> int:
        """估算两个日期之间的交易日数 (简化: 自然日 × 5/7)"""
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
            natural_days = (end - start).days
            return max(0, int(natural_days * 5 / 7))
        except ValueError:
            return 0

    def _track_single(self, rec: dict, holding_days: int) -> Optional[dict]:
        """追踪单个推荐标的

        Args:
            rec: 推荐记录 (含 ticker/trade_date/stop_loss/take_profit 等)
            holding_days: 持仓周期

        Returns:
            追踪结果 dict, 或 None (数据获取失败时)
        """
        ticker = rec["ticker"]
        trade_date = rec["trade_date"]

        stop_loss = rec.get("stop_loss")
        take_profit = rec.get("take_profit")
        target_price = rec.get("target_price")

        # 获取 T+1 ~ T+N 的日线数据
        prices = self._fetch_post_recommendation_prices(ticker, trade_date, holding_days)
        if not prices:
            logger.warning(f"[追踪] {ticker} 无法获取 T+1~T+{holding_days} 价格数据")
            return None

        # 入场价: T 日收盘价 (推荐日收盘)
        entry_price = self._fetch_close_on_date(ticker, trade_date)
        if entry_price is None or entry_price <= 0:
            # fallback: 用 prices[0] 的前一日, 或直接用 target_price 估算
            entry_price = prices[0] if prices else (target_price or 0.0)
            logger.warning(
                f"[追踪] {ticker} 无法获取入场价, 使用 {entry_price} 作为替代"
            )

        # 逐日检查止损/止盈
        outcome = "held_to_expiry"
        exit_price = prices[-1]
        holding_days_actual = holding_days

        for day_idx, close in enumerate(prices, 1):
            # 检查止损
            if stop_loss and close <= stop_loss:
                outcome = "stop_loss_hit"
                exit_price = close
                holding_days_actual = day_idx
                logger.info(
                    f"[追踪] {ticker} T+{day_idx} 触及止损 "
                    f"(close={close:.2f} <= stop_loss={stop_loss:.2f})"
                )
                break

            # 检查止盈
            if take_profit and close >= take_profit:
                outcome = "take_profit_hit"
                exit_price = close
                holding_days_actual = day_idx
                logger.info(
                    f"[追踪] {ticker} T+{day_idx} 触及止盈 "
                    f"(close={close:.2f} >= take_profit={take_profit:.2f})"
                )
                break

        # 计算收益率
        return_pct = ((exit_price - entry_price) / entry_price * 100) if entry_price > 0 else 0.0

        # 计算最大收益和最大回撤
        max_price = max(prices)
        min_price = min(prices)
        max_return_pct = (
            ((max_price - entry_price) / entry_price * 100) if entry_price > 0 else 0.0
        )
        max_drawdown_pct = (
            ((min_price - entry_price) / entry_price * 100) if entry_price > 0 else 0.0
        )

        # 基准收益 (沪深300)
        benchmark_return = self._fetch_benchmark_return(trade_date, holding_days_actual)

        # 保存结果
        self.db.save_outcome(
            trade_date=trade_date,
            ticker=ticker,
            outcome=outcome,
            holding_days=holding_days_actual,
            entry_price=entry_price,
            exit_price=exit_price,
            return_pct=return_pct,
            max_return_pct=max_return_pct,
            max_drawdown_pct=max_drawdown_pct,
            daily_prices=prices,
            benchmark_return_pct=benchmark_return,
        )

        return {
            "outcome": outcome,
            "return_pct": return_pct,
            "exit_price": exit_price,
            "entry_price": entry_price,
            "holding_days": holding_days_actual,
        }

    def _fetch_post_recommendation_prices(
        self, ticker: str, trade_date: str, holding_days: int
    ) -> List[float]:
        """获取推荐日之后 N 个交易日的收盘价

        使用 DataSourceManager 的 get_stock_data 接口获取日线数据。
        """
        try:
            from stock_agent.dataflows.interface import get_stock_data

            # 计算日期范围 (多取一些自然日以确保有足够交易日)
            start_dt = datetime.strptime(trade_date, "%Y-%m-%d")
            # T+1 开始
            fetch_start = (start_dt + timedelta(days=1)).strftime("%Y-%m-%d")
            # 多取 10 天自然日 buffer (考虑周末/节假日)
            fetch_end = (start_dt + timedelta(days=holding_days * 2 + 10)).strftime(
                "%Y-%m-%d"
            )

            result = get_stock_data(ticker, fetch_start, fetch_end)
            if not result or not result.get("data"):
                logger.warning(f"[追踪] {ticker} 无行情数据")
                return []

            data = result["data"]
            closes = []
            for row in data:
                # 兼容不同数据源的列名
                close = _extract_close(row)
                if close is not None and close > 0:
                    closes.append(close)

            # 只取前 holding_days 个交易日
            closes = closes[:holding_days]
            logger.info(
                f"[追踪] {ticker} 获取 {len(closes)} 个交易日收盘价 "
                f"(trade_date={trade_date}, holding={holding_days})"
            )
            return closes

        except Exception as e:
            logger.error(f"[追踪] {ticker} 获取价格失败: {e}")
            return []

    def _fetch_close_on_date(self, ticker: str, date_str: str) -> Optional[float]:
        """获取指定日期的收盘价"""
        try:
            from stock_agent.dataflows.interface import get_stock_data

            result = get_stock_data(ticker, date_str, date_str)
            if not result or not result.get("data"):
                return None

            data = result["data"]
            if data:
                return _extract_close(data[0])
            return None
        except Exception:
            return None

    def _fetch_benchmark_return(self, trade_date: str, holding_days: int) -> float:
        """获取基准 (沪深300) 同期收益率"""
        try:
            from stock_agent.dataflows.interface import get_stock_data

            start_dt = datetime.strptime(trade_date, "%Y-%m-%d")
            fetch_start = date_str = start_dt.strftime("%Y-%m-%d")
            fetch_end = (start_dt + timedelta(days=holding_days * 2 + 10)).strftime(
                "%Y-%m-%d"
            )

            result = get_stock_data(self.BENCHMARK_TICKER, fetch_start, fetch_end)
            if not result or not result.get("data"):
                return 0.0

            data = result["data"]
            closes = []
            for row in data:
                close = _extract_close(row)
                if close is not None and close > 0:
                    closes.append(close)

            if len(closes) < 2:
                return 0.0

            # 基准收益 = (期末收盘 - 期初收盘) / 期初收盘
            bench_start = closes[0]
            bench_end = closes[min(holding_days, len(closes) - 1)]
            if bench_start > 0:
                return (bench_end - bench_start) / bench_start * 100
            return 0.0

        except Exception as e:
            logger.debug(f"[追踪] 基准收益获取失败: {e}")
            return 0.0

    def generate_run_stats_for_date(self, trade_date: str) -> Optional[dict]:
        """为指定日期的推荐生成运行统计

        在追踪完成后调用, 聚合该日期所有推荐标的的结果。
        """
        recs = self.db.get_recommendations_by_date(trade_date)
        outcomes = self.db.get_outcomes_by_date(trade_date)

        if not recs:
            return None

        total_recs = len(recs)
        total_tracked = len(outcomes)
        hit_count = sum(1 for o in outcomes if o.get("return_pct", 0) > 0)
        returns = [o.get("return_pct", 0) for o in outcomes if o.get("return_pct") is not None]
        avg_return = sum(returns) / len(returns) if returns else 0.0
        max_dd = max((abs(o.get("max_drawdown_pct", 0)) for o in outcomes), default=0.0)
        bench_returns = [o.get("benchmark_return_pct", 0) for o in outcomes if o.get("benchmark_return_pct") is not None]
        avg_bench = sum(bench_returns) / len(bench_returns) if bench_returns else 0.0

        # 简化夏普
        from stock_agent.eval.performance_db import _calc_sharpe
        sharpe = _calc_sharpe(returns)

        # 市场环境判断 (基于基准收益)
        market_regime = "sideways"
        if avg_bench > 2.0:
            market_regime = "bull"
        elif avg_bench < -2.0:
            market_regime = "bear"

        self.db.save_run_stats(
            trade_date=trade_date,
            total_recommendations=total_recs,
            total_tracked=total_tracked,
            hit_count=hit_count,
            avg_return_pct=avg_return,
            sharpe_ratio=sharpe,
            max_drawdown_pct=max_dd,
            benchmark_return_pct=avg_bench,
            market_regime=market_regime,
        )

        stats = {
            "trade_date": trade_date,
            "total_recommendations": total_recs,
            "total_tracked": total_tracked,
            "hit_rate": hit_count / total_tracked if total_tracked > 0 else 0.0,
            "avg_return_pct": avg_return,
            "sharpe_ratio": sharpe,
            "max_drawdown_pct": max_dd,
            "benchmark_return_pct": avg_bench,
            "market_regime": market_regime,
        }
        logger.info(
            f"[追踪] 运行统计 {trade_date}: "
            f"命中率={stats['hit_rate']:.1%} 平均收益={avg_return:+.2f}% "
            f"夏普={sharpe:.2f} 市场={market_regime}"
        )
        return stats


def _extract_close(row: Any) -> Optional[float]:
    """从行情数据行中提取收盘价 (兼容不同数据源列名)"""
    if isinstance(row, dict):
        for key in ("close", "收盘", "closing_price", "price"):
            val = row.get(key)
            if val is not None:
                try:
                    return float(val)
                except (TypeError, ValueError):
                    continue
    elif isinstance(row, (list, tuple)):
        # 假设 close 在倒数第一或倒数第二位
        for idx in (-1, -2, -3):
            try:
                if abs(idx) <= len(row):
                    return float(row[idx])
            except (TypeError, ValueError, IndexError):
                continue
    return None
