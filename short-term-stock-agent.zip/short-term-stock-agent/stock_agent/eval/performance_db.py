"""
性能数据库 (V3 新增, 对应升级方案阶段一)

SQLite 持久化存储所有推荐标的及其后续追踪结果, 支持按标的/板块/分析师维度/
置信度/日期等多维度查询, 为反馈注入器和归因分析提供数据基础。

数据库表结构:
  1. recommendations: 每次推荐的标的记录 (含目标价/止损/置信度/评级/来源等)
  2. outcomes:        推荐标的的追踪结果 (T+1~T+N 收益率/是否止损/是否止盈)
  3. run_stats:       每次运行的整体统计 (命中率/平均收益/夏普比率)

使用方式:
    from stock_agent.eval.performance_db import PerformanceDB
    db = PerformanceDB()
    db.save_recommendations(trade_date, portfolio, config)
    db.save_outcome(ticker, trade_date, outcome_data)
    stats = db.get_performance_summary(lookback_days=30)
"""
import os
import json
import sqlite3
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from loguru import logger


class PerformanceDB:
    """性能数据库 (SQLite, 线程安全)

    存储推荐记录与追踪结果, 支持多维度聚合查询。
    单例模式: 全局只有一个数据库实例。
    """

    _instance: Optional["PerformanceDB"] = None
    _lock = threading.Lock()

    def __new__(cls, db_path: str = None):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._init(db_path)
            return cls._instance

    def _init(self, db_path: str = None):
        """初始化数据库连接与表结构"""
        if db_path is None:
            results_dir = os.getenv("RESULTS_DIR", "./results")
            os.makedirs(results_dir, exist_ok=True)
            db_path = os.path.join(results_dir, "performance.db")

        self.db_path = db_path
        self._local = threading.local()
        logger.info(f"[性能DB] 数据库路径: {db_path}")

        # 初始化表结构
        self._init_schema()

    def _get_conn(self) -> sqlite3.Connection:
        """获取线程安全的数据库连接 (每线程独立连接)"""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                self.db_path, timeout=10, check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_schema(self):
        """创建数据库表结构"""
        conn = self._get_conn()
        cursor = conn.cursor()

        # 推荐记录表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS recommendations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_date TEXT NOT NULL,
                ticker TEXT NOT NULL,
                name TEXT,
                source TEXT,
                rating TEXT,
                target_price REAL,
                take_profit REAL,
                stop_loss REAL,
                confidence REAL,
                risk_level REAL,
                sector TEXT,
                entry_price REAL,
                -- 分析层各维度评级 (用于归因分析)
                fundamentals_rating TEXT,
                technical_rating TEXT,
                china_specific_rating TEXT,
                stock_development_rating TEXT,
                -- 元数据
                user_risk_preference TEXT,
                user_holding_period TEXT,
                created_at TEXT DEFAULT (datetime('now', 'localtime')),
                UNIQUE(trade_date, ticker)
            )
        """)

        # 追踪结果表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_date TEXT NOT NULL,
                ticker TEXT NOT NULL,
                -- 追踪结果
                outcome TEXT NOT NULL,
                -- take_profit_hit / stop_loss_hit / held_to_expiry / still_holding
                holding_days INTEGER,
                entry_price REAL,
                exit_price REAL,
                return_pct REAL,
                max_return_pct REAL,
                max_drawdown_pct REAL,
                -- 追踪时点各日收盘价 (JSON)
                daily_prices TEXT,
                -- 基准收益 (沪深300同期)
                benchmark_return_pct REAL,
                excess_return_pct REAL,
                tracked_at TEXT DEFAULT (datetime('now', 'localtime')),
                UNIQUE(trade_date, ticker),
                FOREIGN KEY(trade_date, ticker)
                    REFERENCES recommendations(trade_date, ticker)
            )
        """)

        # 运行统计表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS run_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_date TEXT NOT NULL UNIQUE,
                total_recommendations INTEGER,
                total_tracked INTEGER,
                hit_count INTEGER,
                hit_rate REAL,
                avg_return_pct REAL,
                sharpe_ratio REAL,
                max_drawdown_pct REAL,
                benchmark_return_pct REAL,
                excess_return_pct REAL,
                -- 市场环境标记 (bull/bear/sideways)
                market_regime TEXT,
                config_snapshot TEXT,
                created_at TEXT DEFAULT (datetime('now', 'localtime'))
            )
        """)

        # 创建索引
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_rec_date ON recommendations(trade_date)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_rec_ticker ON recommendations(ticker)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_rec_sector ON recommendations(sector)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_outcome_date ON outcomes(trade_date)"
        )

        conn.commit()
        logger.info("[性能DB] 表结构初始化完成")

    def reset(self):
        """重置单例 (测试用)"""
        PerformanceDB._instance = None

    # =================================================================
    # 写入接口
    # =================================================================

    def save_recommendations(
        self,
        trade_date: str,
        portfolio: List[dict],
        user_config: dict = None,
        analysis_reports: dict = None,
    ) -> int:
        """保存一次运行的全部推荐标的

        Args:
            trade_date: 推荐日期 (YYYY-MM-DD)
            portfolio: 最终推荐清单 (final_portfolio)
            user_config: 用户配置 (风险偏好/持仓周期)
            analysis_reports: 四维分析报告 (用于提取各维度评级)

        Returns:
            保存的记录数
        """
        conn = self._get_conn()
        cursor = conn.cursor()
        user_config = user_config or {}
        analysis_reports = analysis_reports or {}

        count = 0
        for stock in portfolio:
            ticker = stock.get("ticker", "")
            if not ticker:
                continue

            # 从分析报告中提取各维度评级
            ticker_reports = analysis_reports.get(ticker, {})
            fund_rating = ticker_reports.get("fundamentals", {}).get("rating", "")
            tech_rating = ticker_reports.get("technical", {}).get("rating", "")
            china_rating = ticker_reports.get("china_specific", {}).get("rating", "")
            dev_rating = ticker_reports.get("stock_development", {}).get("rating", "")

            cursor.execute(
                """
                INSERT OR REPLACE INTO recommendations
                    (trade_date, ticker, name, source, rating, target_price,
                     take_profit, stop_loss, confidence, risk_level, sector,
                     entry_price, fundamentals_rating, technical_rating,
                     china_specific_rating, stock_development_rating,
                     user_risk_preference, user_holding_period)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trade_date,
                    ticker,
                    stock.get("name", ""),
                    stock.get("source", ""),
                    stock.get("rating", ""),
                    _to_float(stock.get("target_price")),
                    _to_float(stock.get("take_profit")),
                    _to_float(stock.get("stop_loss")),
                    _to_float(stock.get("confidence")),
                    _to_float(stock.get("risk_level")),
                    stock.get("sector", ""),
                    _to_float(stock.get("entry_price")),
                    fund_rating,
                    tech_rating,
                    china_rating,
                    dev_rating,
                    user_config.get("risk_preference", ""),
                    user_config.get("holding_period", ""),
                ),
            )
            count += 1

        conn.commit()
        logger.info(
            f"[性能DB] 保存 {count} 条推荐记录 (trade_date={trade_date})"
        )
        return count

    def save_outcome(
        self,
        trade_date: str,
        ticker: str,
        outcome: str,
        holding_days: int = 0,
        entry_price: float = 0.0,
        exit_price: float = 0.0,
        return_pct: float = 0.0,
        max_return_pct: float = 0.0,
        max_drawdown_pct: float = 0.0,
        daily_prices: list = None,
        benchmark_return_pct: float = 0.0,
    ) -> bool:
        """保存单个推荐标的的追踪结果

        Args:
            trade_date: 推荐日期
            ticker: 股票代码
            outcome: 结果类型 (take_profit_hit/stop_loss_hit/held_to_expiry/still_holding)
            holding_days: 持有天数
            entry_price: 入场价
            exit_price: 出场价
            return_pct: 收益率 (百分比)
            max_return_pct: 持仓期内最大收益率
            max_drawdown_pct: 持仓期内最大回撤
            daily_prices: 各日收盘价列表
            benchmark_return_pct: 基准同期收益率

        Returns:
            是否保存成功
        """
        conn = self._get_conn()
        cursor = conn.cursor()

        excess = return_pct - benchmark_return_pct if benchmark_return_pct else None

        try:
            cursor.execute(
                """
                INSERT OR REPLACE INTO outcomes
                    (trade_date, ticker, outcome, holding_days, entry_price,
                     exit_price, return_pct, max_return_pct, max_drawdown_pct,
                     daily_prices, benchmark_return_pct, excess_return_pct)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trade_date,
                    ticker,
                    outcome,
                    holding_days,
                    entry_price,
                    exit_price,
                    return_pct,
                    max_return_pct,
                    max_drawdown_pct,
                    json.dumps(daily_prices or [], ensure_ascii=False),
                    benchmark_return_pct,
                    excess,
                ),
            )
            conn.commit()
            logger.info(
                f"[性能DB] 保存追踪结果: {ticker} trade_date={trade_date} "
                f"outcome={outcome} return={return_pct:+.2f}%"
            )
            return True
        except Exception as e:
            logger.error(f"[性能DB] 保存追踪结果失败: {ticker} - {e}")
            return False

    def save_run_stats(
        self,
        trade_date: str,
        total_recommendations: int,
        total_tracked: int,
        hit_count: int,
        avg_return_pct: float,
        sharpe_ratio: float = 0.0,
        max_drawdown_pct: float = 0.0,
        benchmark_return_pct: float = 0.0,
        market_regime: str = "",
        config_snapshot: dict = None,
    ) -> bool:
        """保存一次运行的整体统计"""
        conn = self._get_conn()
        cursor = conn.cursor()
        hit_rate = hit_count / total_tracked if total_tracked > 0 else 0.0
        excess = avg_return_pct - benchmark_return_pct if benchmark_return_pct else 0.0

        try:
            cursor.execute(
                """
                INSERT OR REPLACE INTO run_stats
                    (trade_date, total_recommendations, total_tracked, hit_count,
                     hit_rate, avg_return_pct, sharpe_ratio, max_drawdown_pct,
                     benchmark_return_pct, excess_return_pct, market_regime,
                     config_snapshot)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trade_date,
                    total_recommendations,
                    total_tracked,
                    hit_count,
                    hit_rate,
                    avg_return_pct,
                    sharpe_ratio,
                    max_drawdown_pct,
                    benchmark_return_pct,
                    excess,
                    market_regime,
                    json.dumps(config_snapshot or {}, ensure_ascii=False),
                ),
            )
            conn.commit()
            return True
        except Exception as e:
            logger.error(f"[性能DB] 保存运行统计失败: {e}")
            return False

    # =================================================================
    # 查询接口
    # =================================================================

    def get_untracked_recommendations(self) -> List[dict]:
        """获取尚未追踪结果的推荐记录 (推荐日期距今超过持仓周期的)"""
        conn = self._get_conn()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT r.* FROM recommendations r
            LEFT JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
            WHERE o.id IS NULL
            ORDER BY r.trade_date ASC
            """
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_recommendations_by_date(self, trade_date: str) -> List[dict]:
        """获取指定日期的全部推荐"""
        conn = self._get_conn()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM recommendations WHERE trade_date = ? ORDER BY ticker",
            (trade_date,),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_outcomes_by_date(self, trade_date: str) -> List[dict]:
        """获取指定日期的全部追踪结果"""
        conn = self._get_conn()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM outcomes WHERE trade_date = ? ORDER BY ticker",
            (trade_date,),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_performance_summary(
        self,
        lookback_days: int = 30,
        end_date: str = None,
    ) -> dict:
        """获取近 N 天的性能摘要 (核心查询, 反馈注入器使用)

        Args:
            lookback_days: 回看天数
            end_date: 截止日期 (None 则用今天)

        Returns:
            {
                "total_count": int,
                "tracked_count": int,
                "hit_rate": float,
                "avg_return_pct": float,
                "sharpe_ratio": float,
                "max_drawdown_pct": float,
                "by_sector": {sector: {count, hit_rate, avg_return}},
                "by_analyst": {analyst_dim: {count, hit_rate, avg_return}},
                "by_confidence": {"high": {...}, "medium": {...}, "low": {...}},
                "failure_patterns": [{"pattern": str, "count": int}],
                "recent_trades": [...],
            }
        """
        conn = self._get_conn()
        cursor = conn.cursor()

        if end_date is None:
            end_date = datetime.now().strftime("%Y-%m-%d")
        start_date = (
            datetime.strptime(end_date, "%Y-%m-%d") - timedelta(days=lookback_days)
        ).strftime("%Y-%m-%d")

        # === 整体指标 ===
        cursor.execute(
            """
            SELECT
                COUNT(DISTINCT r.ticker) as total_count,
                COUNT(o.ticker) as tracked_count,
                SUM(CASE WHEN o.return_pct > 0 THEN 1 ELSE 0 END) as hit_count,
                AVG(o.return_pct) as avg_return,
                MAX(o.max_drawdown_pct) as max_dd,
                AVG(o.excess_return_pct) as avg_excess
            FROM recommendations r
            LEFT JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
            WHERE r.trade_date BETWEEN ? AND ?
            """,
            (start_date, end_date),
        )
        row = cursor.fetchone()

        total_count = row["total_count"] or 0
        tracked_count = row["tracked_count"] or 0
        hit_count = row["hit_count"] or 0
        avg_return = row["avg_return"] or 0.0
        max_dd = row["max_dd"] or 0.0
        avg_excess = row["avg_excess"] or 0.0
        hit_rate = hit_count / tracked_count if tracked_count > 0 else 0.0

        # 夏普比率 (简化: 用所有追踪标的的收益序列)
        cursor.execute(
            """
            SELECT o.return_pct FROM outcomes o
            JOIN recommendations r ON o.trade_date = r.trade_date AND o.ticker = r.ticker
            WHERE r.trade_date BETWEEN ? AND ? AND o.return_pct IS NOT NULL
            """,
            (start_date, end_date),
        )
        returns = [row["return_pct"] for row in cursor.fetchall() if row["return_pct"] is not None]
        sharpe = _calc_sharpe(returns)

        # === 按板块分组 ===
        cursor.execute(
            """
            SELECT r.sector,
                   COUNT(*) as count,
                   SUM(CASE WHEN o.return_pct > 0 THEN 1 ELSE 0 END) as hits,
                   AVG(o.return_pct) as avg_ret
            FROM recommendations r
            LEFT JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
            WHERE r.trade_date BETWEEN ? AND ? AND o.return_pct IS NOT NULL
            GROUP BY r.sector
            ORDER BY count DESC
            """,
            (start_date, end_date),
        )
        by_sector = {}
        for row in cursor.fetchall():
            sector = row["sector"] or "未知"
            cnt = row["count"] or 0
            hts = row["hits"] or 0
            by_sector[sector] = {
                "count": cnt,
                "hit_rate": hts / cnt if cnt > 0 else 0.0,
                "avg_return": row["avg_ret"] or 0.0,
            }

        # === 按分析师维度分组 ===
        by_analyst = {}
        for dim_col, dim_name in [
            ("fundamentals_rating", "fundamentals"),
            ("technical_rating", "technical"),
            ("china_specific_rating", "china_specific"),
            ("stock_development_rating", "stock_development"),
        ]:
            cursor.execute(
                f"""
                SELECT r.{dim_col} as rating,
                       COUNT(*) as count,
                       SUM(CASE WHEN o.return_pct > 0 THEN 1 ELSE 0 END) as hits,
                       AVG(o.return_pct) as avg_ret
                FROM recommendations r
                LEFT JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
                WHERE r.trade_date BETWEEN ? AND ?
                  AND r.{dim_col} IS NOT NULL AND r.{dim_col} != ''
                  AND o.return_pct IS NOT NULL
                GROUP BY r.{dim_col}
                """,
                (start_date, end_date),
            )
            dim_stats = {}
            for row in cursor.fetchall():
                rating = row["rating"] or "未知"
                cnt = row["count"] or 0
                hts = row["hits"] or 0
                dim_stats[rating] = {
                    "count": cnt,
                    "hit_rate": hts / cnt if cnt > 0 else 0.0,
                    "avg_return": row["avg_ret"] or 0.0,
                }
            by_analyst[dim_name] = dim_stats

        # === 按置信度分组 ===
        cursor.execute(
            """
            SELECT
                CASE
                    WHEN r.confidence >= 0.7 THEN 'high'
                    WHEN r.confidence >= 0.5 THEN 'medium'
                    ELSE 'low'
                END as conf_bucket,
                COUNT(*) as count,
                SUM(CASE WHEN o.return_pct > 0 THEN 1 ELSE 0 END) as hits,
                AVG(o.return_pct) as avg_ret
            FROM recommendations r
            LEFT JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
            WHERE r.trade_date BETWEEN ? AND ? AND o.return_pct IS NOT NULL
            GROUP BY conf_bucket
            """,
            (start_date, end_date),
        )
        by_confidence = {}
        for row in cursor.fetchall():
            bucket = row["conf_bucket"] or "unknown"
            cnt = row["count"] or 0
            hts = row["hits"] or 0
            by_confidence[bucket] = {
                "count": cnt,
                "hit_rate": hts / cnt if cnt > 0 else 0.0,
                "avg_return": row["avg_ret"] or 0.0,
            }

        # === 失败模式分析 ===
        cursor.execute(
            """
            SELECT r.sector, r.rating, r.source,
                   COUNT(*) as count, AVG(o.return_pct) as avg_ret
            FROM recommendations r
            JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
            WHERE r.trade_date BETWEEN ? AND ?
              AND o.return_pct < 0
            GROUP BY r.sector, r.rating, r.source
            ORDER BY count DESC
            LIMIT 5
            """,
            (start_date, end_date),
        )
        failure_patterns = []
        for row in cursor.fetchall():
            failure_patterns.append(
                {
                    "pattern": f"{row['sector'] or '未知'}/{row['rating'] or '未知'}/{row['source'] or '未知'}",
                    "count": row["count"],
                    "avg_return": row["avg_ret"] or 0.0,
                }
            )

        # === 最近交易 ===
        cursor.execute(
            """
            SELECT r.trade_date, r.ticker, r.name, r.sector, r.rating,
                   r.confidence, o.outcome, o.return_pct, o.holding_days
            FROM recommendations r
            JOIN outcomes o ON r.trade_date = o.trade_date AND r.ticker = o.ticker
            WHERE r.trade_date BETWEEN ? AND ?
            ORDER BY r.trade_date DESC
            LIMIT 10
            """,
            (start_date, end_date),
        )
        recent_trades = [dict(row) for row in cursor.fetchall()]

        return {
            "lookback_days": lookback_days,
            "start_date": start_date,
            "end_date": end_date,
            "total_count": total_count,
            "tracked_count": tracked_count,
            "hit_count": hit_count,
            "hit_rate": hit_rate,
            "avg_return_pct": avg_return,
            "sharpe_ratio": sharpe,
            "max_drawdown_pct": max_dd,
            "avg_excess_return_pct": avg_excess,
            "by_sector": by_sector,
            "by_analyst": by_analyst,
            "by_confidence": by_confidence,
            "failure_patterns": failure_patterns,
            "recent_trades": recent_trades,
        }

    def get_all_tracked_dates(self) -> List[str]:
        """获取所有有追踪结果的推荐日期"""
        conn = self._get_conn()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT trade_date FROM outcomes ORDER BY trade_date DESC"
        )
        return [row["trade_date"] for row in cursor.fetchall()]

    def get_all_recommendation_dates(self) -> List[str]:
        """获取所有有推荐记录的日期"""
        conn = self._get_conn()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT trade_date FROM recommendations ORDER BY trade_date DESC"
        )
        return [row["trade_date"] for row in cursor.fetchall()]


# =================================================================
# 辅助函数
# =================================================================

def _to_float(value) -> Optional[float]:
    """安全转换为 float, 失败返回 None"""
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _calc_sharpe(returns: List[float], risk_free_rate: float = 2.0) -> float:
    """计算简化夏普比率 (年化)

    Args:
        returns: 收益率列表 (百分比)
        risk_free_rate: 无风险年化利率 (默认 2%)

    Returns:
        夏普比率 (年化), 无数据时返回 0
    """
    if not returns or len(returns) < 2:
        return 0.0

    import math

    avg_ret = sum(returns) / len(returns)
    variance = sum((r - avg_ret) ** 2 for r in returns) / (len(returns) - 1)
    std = math.sqrt(variance)

    if std == 0:
        return 0.0

    # 简化年化: 假设持仓 3 天, 一年约 80 个持仓周期
    annualized_return = avg_ret * 80
    annualized_std = std * math.sqrt(80)

    return (annualized_return - risk_free_rate) / annualized_std if annualized_std > 0 else 0.0
