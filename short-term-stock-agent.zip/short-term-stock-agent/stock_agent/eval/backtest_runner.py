"""
批量回测调度器 (V3 新增, 对应升级方案阶段四)

对历史日期批量重放 Agent 推荐, 追踪结果并聚合统计, 实现:
  1. 指定日期范围批量回测 (跳过非交易日)
  2. 每个日期独立运行 Agent, 结果存入 PerformanceDB
  3. 回测完成后自动追踪所有推荐标的的结果
  4. 聚合统计: 命中率/平均收益/夏普比率/最大回撤/板块分布
  5. 可选: 回测后自动执行归因分析 + 参数调优

使用方式:
    from stock_agent.eval.backtest_runner import BacktestRunner
    runner = BacktestRunner(config)
    result = runner.run_backtest(
        start_date="2025-06-01",
        end_date="2025-07-01",
        holding_days=5,
    )
    # result 含回测统计摘要
"""
import os
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
from loguru import logger

from stock_agent.eval.performance_db import PerformanceDB
from stock_agent.eval.outcome_tracker import OutcomeTracker
from stock_agent.eval.attribution_engine import AttributionEngine
from stock_agent.eval.param_optimizer import ParamOptimizer


class BacktestRunner:
    """批量回测调度器

    对历史日期批量运行 Agent, 追踪结果并聚合统计。
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.db = PerformanceDB(db_path=self.config.get("performance_db_path"))
        self.tracker = OutcomeTracker(config)
        self.max_concurrent = int(self.config.get("backtest_max_concurrent", 1))
        self.timeout_per_run = int(self.config.get("backtest_timeout_per_run", 1800))
        self.results_dir = self.config.get("results_dir", "./results")

    def run_backtest(
        self,
        start_date: str,
        end_date: str,
        holding_days: int = None,
        skip_existing: bool = True,
        run_agent_fn: callable = None,
    ) -> dict:
        """执行批量回测

        Args:
            start_date: 回测开始日期 (YYYY-MM-DD)
            end_date: 回测结束日期 (YYYY-MM-DD)
            holding_days: 持仓天数 (None 则用配置默认值)
            skip_existing: 跳过已有推荐记录的日期
            run_agent_fn: Agent 运行函数, 签名: fn(trade_date: str) -> dict
                          返回 {"portfolio": [...], "analysis_reports": {...}}
                          如果为 None, 则仅追踪已有推荐 (不重新运行 Agent)

        Returns:
            回测结果摘要 dict
        """
        logger.info(
            f"[回测] 开始回测: {start_date} ~ {end_date}, "
            f"holding_days={holding_days}, skip_existing={skip_existing}"
        )

        # 生成交易日列表 (简化: 跳过周末)
        trade_dates = self._generate_trade_dates(start_date, end_date)
        logger.info(f"[回测] 共 {len(trade_dates)} 个候选交易日")

        # 过滤已有记录的日期
        if skip_existing:
            existing_dates = set(self.db.get_all_recommendation_dates())
            trade_dates = [d for d in trade_dates if d not in existing_dates]
            logger.info(
                f"[回测] 跳过 {len(existing_dates)} 个已有记录日期, "
                f"剩余 {len(trade_dates)} 个待回测"
            )

        if not trade_dates:
            logger.info("[回测] 无需回测的日期, 直接进入追踪阶段")
        else:
            # 执行回测
            if run_agent_fn is not None:
                self._run_agent_for_dates(trade_dates, run_agent_fn)
            else:
                logger.warning(
                    "[回测] 未提供 run_agent_fn, 跳过 Agent 运行 (仅追踪已有推荐)"
                )

        # 追踪所有未追踪的推荐
        logger.info("[回测] 开始追踪推荐结果...")
        track_result = self.tracker.track_all_pending(
            force_holding_days=holding_days
        )
        logger.info(
            f"[回测] 追踪完成: 追踪{track_result['tracked']}只, "
            f"跳过{track_result['skipped']}只, 失败{track_result['failed']}只"
        )

        # 生成各日期的运行统计
        all_dates = self.db.get_all_recommendation_dates()
        for date_str in all_dates:
            self.tracker.generate_run_stats_for_date(date_str)

        # 聚合统计
        summary = self._generate_backtest_summary(start_date, end_date, holding_days)

        # 可选: 自动归因分析 + 参数调优
        if self.config.get("attribution_enabled", True):
            logger.info("[回测] 执行归因分析...")
            try:
                engine = AttributionEngine(self.config)
                attribution_report = engine.run_full_attribution(
                    lookback_days=self.config.get("attribution_lookback_days", 60)
                )
                summary["attribution_report"] = attribution_report

                if self.config.get("param_optimization_enabled", True):
                    logger.info("[回测] 执行参数调优...")
                    optimizer = ParamOptimizer(self.config)
                    optimization_result = optimizer.optimize(
                        lookback_days=self.config.get("attribution_lookback_days", 60),
                        dry_run=True,
                    )
                    summary["optimization_result"] = optimization_result
            except Exception as e:
                logger.error(f"[回测] 归因/调优失败 (不影响回测结果): {e}")

        # 保存回测报告
        self._save_backtest_report(summary)

        logger.info(
            f"[回测] 回测完成: 总推荐{summary['total_recommendations']}只, "
            f"已追踪{summary['total_tracked']}只, "
            f"命中率{summary['hit_rate']:.1%}, "
            f"平均收益{summary['avg_return_pct']:+.2f}%"
        )

        return summary

    def _generate_trade_dates(self, start_date: str, end_date: str) -> List[str]:
        """生成交易日列表 (跳过周末, 简化版不含节假日)"""
        dates = []
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
        except ValueError:
            logger.error(f"[回测] 日期格式错误: {start_date} ~ {end_date}")
            return []

        current = start
        while current <= end:
            # 跳过周末 (0=周一, 6=周日)
            if current.weekday() < 5:
                dates.append(current.strftime("%Y-%m-%d"))
            current += timedelta(days=1)

        return dates

    def _run_agent_for_dates(self, trade_dates: List[str], run_agent_fn: callable):
        """对每个交易日运行 Agent"""
        if self.max_concurrent <= 1:
            # 串行执行
            for i, date_str in enumerate(trade_dates, 1):
                logger.info(f"[回测] ({i}/{len(trade_dates)}) 运行 Agent: {date_str}")
                self._run_agent_single(date_str, run_agent_fn)
        else:
            # 并行执行
            with ThreadPoolExecutor(max_workers=self.max_concurrent) as ex:
                futures = {
                    ex.submit(self._run_agent_single, date_str, run_agent_fn): date_str
                    for date_str in trade_dates
                }
                for fut in as_completed(futures, timeout=self.timeout_per_run * len(trade_dates)):
                    date_str = futures[fut]
                    try:
                        fut.result(timeout=self.timeout_per_run)
                    except Exception as e:
                        logger.error(f"[回测] {date_str} 运行失败: {e}")

    def _run_agent_single(self, trade_date: str, run_agent_fn: callable) -> bool:
        """运行单个日期的 Agent"""
        start_time = time.time()
        try:
            result = run_agent_fn(trade_date)
            if not result:
                logger.warning(f"[回测] {trade_date} Agent 返回空结果")
                return False

            portfolio = result.get("portfolio", [])
            analysis_reports = result.get("analysis_reports", {})
            user_config = result.get("user_config", {})

            if portfolio:
                self.db.save_recommendations(
                    trade_date=trade_date,
                    portfolio=portfolio,
                    user_config=user_config,
                    analysis_reports=analysis_reports,
                )
            else:
                logger.warning(f"[回测] {trade_date} 无推荐标的")

            elapsed = time.time() - start_time
            logger.info(
                f"[回测] {trade_date} 完成: {len(portfolio)}只推荐, 耗时{elapsed:.1f}s"
            )
            return True

        except Exception as e:
            logger.error(f"[回测] {trade_date} Agent 运行异常: {e}")
            return False

    def _generate_backtest_summary(
        self, start_date: str, end_date: str, holding_days: int = None
    ) -> dict:
        """生成回测统计摘要"""
        lookback_days = (
            datetime.strptime(end_date, "%Y-%m-%d")
            - datetime.strptime(start_date, "%Y-%m-%d")
        ).days + 10

        stats = self.db.get_performance_summary(lookback_days=lookback_days)

        # 按日期统计
        all_dates = self.db.get_all_recommendation_dates()
        daily_stats = []
        for date_str in all_dates:
            recs = self.db.get_recommendations_by_date(date_str)
            outcomes = self.db.get_outcomes_by_date(date_str)
            if recs:
                returns = [
                    o.get("return_pct", 0) for o in outcomes
                    if o.get("return_pct") is not None
                ]
                daily_stats.append({
                    "trade_date": date_str,
                    "recommendations": len(recs),
                    "tracked": len(outcomes),
                    "hit_rate": (
                        sum(1 for r in returns if r > 0) / len(returns)
                        if returns else 0
                    ),
                    "avg_return": sum(returns) / len(returns) if returns else 0,
                })

        return {
            "backtest_start": start_date,
            "backtest_end": end_date,
            "holding_days": holding_days,
            "total_dates": len(all_dates),
            "total_recommendations": stats["total_count"],
            "total_tracked": stats["tracked_count"],
            "hit_rate": stats["hit_rate"],
            "avg_return_pct": stats["avg_return_pct"],
            "sharpe_ratio": stats["sharpe_ratio"],
            "max_drawdown_pct": stats["max_drawdown_pct"],
            "avg_excess_return_pct": stats.get("avg_excess_return_pct", 0),
            "by_sector": stats.get("by_sector", {}),
            "by_analyst": stats.get("by_analyst", {}),
            "by_confidence": stats.get("by_confidence", {}),
            "failure_patterns": stats.get("failure_patterns", []),
            "daily_stats": daily_stats,
            "generated_at": datetime.now().isoformat(),
        }

    def _save_backtest_report(self, summary: dict):
        """保存回测报告"""
        try:
            report_dir = os.path.join(self.results_dir, "backtest_reports")
            os.makedirs(report_dir, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"backtest_{summary['backtest_start']}_{summary['backtest_end']}_{timestamp}.json"
            report_path = os.path.join(report_dir, filename)

            # 序列化 (处理不可序列化的对象)
            def default_serializer(obj):
                if isinstance(obj, (datetime,)):
                    return obj.isoformat()
                if isinstance(obj, float):
                    return round(obj, 4)
                return str(obj)

            with open(report_path, "w", encoding="utf-8") as f:
                json.dump(summary, f, ensure_ascii=False, indent=2, default=default_serializer)

            logger.info(f"[回测] 报告已保存: {report_path}")
        except Exception as e:
            logger.error(f"[回测] 保存报告失败: {e}")

    def generate_backtest_report_text(self, summary: dict = None) -> str:
        """生成回测报告文本"""
        if summary is None:
            # 使用最近一次回测结果
            lookback = self.config.get("attribution_lookback_days", 60)
            stats = self.db.get_performance_summary(lookback_days=lookback)
            summary = {
                "backtest_start": stats.get("start_date", ""),
                "backtest_end": stats.get("end_date", ""),
                "total_recommendations": stats.get("total_count", 0),
                "total_tracked": stats.get("tracked_count", 0),
                "hit_rate": stats.get("hit_rate", 0),
                "avg_return_pct": stats.get("avg_return_pct", 0),
                "sharpe_ratio": stats.get("sharpe_ratio", 0),
                "max_drawdown_pct": stats.get("max_drawdown_pct", 0),
                "avg_excess_return_pct": stats.get("avg_excess_return_pct", 0),
                "by_sector": stats.get("by_sector", {}),
                "daily_stats": [],
            }

        lines = []
        lines.append("### 10. 回测统计")
        lines.append("")
        lines.append(
            f"> 回测区间: {summary.get('backtest_start', 'N/A')} ~ "
            f"{summary.get('backtest_end', 'N/A')} | "
            f"持仓天数: {summary.get('holding_days', 'N/A')}"
        )
        lines.append("")

        # 整体指标
        lines.append("#### 整体表现")
        lines.append(f"- 总推荐数: {summary.get('total_recommendations', 0)}")
        lines.append(f"- 已追踪数: {summary.get('total_tracked', 0)}")
        lines.append(f"- 命中率: {summary.get('hit_rate', 0):.1%}")
        lines.append(f"- 平均收益: {summary.get('avg_return_pct', 0):+.2f}%")
        lines.append(f"- 夏普比率: {summary.get('sharpe_ratio', 0):.2f}")
        lines.append(f"- 最大回撤: {summary.get('max_drawdown_pct', 0):.2f}%")
        lines.append(f"- 超额收益: {summary.get('avg_excess_return_pct', 0):+.2f}%")
        lines.append("")

        # 每日统计
        daily_stats = summary.get("daily_stats", [])
        if daily_stats:
            lines.append("#### 每日回测详情")
            lines.append("| 日期 | 推荐数 | 追踪数 | 命中率 | 平均收益 |")
            lines.append("|------|--------|--------|--------|---------|")
            for ds in daily_stats[:20]:  # 最多显示 20 天
                lines.append(
                    f"| {ds['trade_date']} | {ds['recommendations']} | "
                    f"{ds['tracked']} | {ds['hit_rate']:.0%} | "
                    f"{ds['avg_return']:+.2f}% |"
                )
            if len(daily_stats) > 20:
                lines.append(f"| ... | ({len(daily_stats) - 20} 天省略) | | | |")
            lines.append("")

        # 板块分布
        by_sector = summary.get("by_sector", {})
        if by_sector:
            lines.append("#### 板块表现分布")
            lines.append("| 板块 | 样本数 | 命中率 | 平均收益 |")
            lines.append("|------|--------|--------|---------|")
            sorted_sectors = sorted(
                by_sector.items(),
                key=lambda x: x[1].get("avg_return", 0),
                reverse=True,
            )[:10]
            for sector, s in sorted_sectors:
                lines.append(
                    f"| {sector} | {s.get('count', 0)} | "
                    f"{s.get('hit_rate', 0):.0%} | "
                    f"{s.get('avg_return', 0):+.2f}% |"
                )
            lines.append("")

        return "\n".join(lines)
