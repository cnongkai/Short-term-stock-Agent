"""
腾讯财经数据源 (对应 PRD 6.10, 独立 fallback 数据源)

通过腾讯财经 HTTP API 获取 A 股行情数据, 作为 AkShare/Tushare 之外的独立数据源。
腾讯 API 域名 (web.ifzq.gtimg.cn / qt.gtimg.cn) 与东财/新浪不同, 网络故障时提供差异化覆盖。

支持方法:
  - get_stock_data  : 日线 K 线 (前复权)
  - get_stock_info  : 实时行情摘要 (名称/现价/涨跌幅/成交量等)

所有方法 try/except 包裹, 失败返回空 dict (PRD: 工具优雅降级)。
"""
import json
from loguru import logger

from stock_agent.dataflows.cache import cached


class TencentProvider:
    """腾讯财经数据源 Provider (独立 fallback, 无需 token/依赖)"""

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._timeout = int(self.config.get("tencent_http_timeout", 15))

    def _tencent_symbol(self, ticker: str) -> str:
        """生成腾讯符号格式: sh600584 / sz000001 / sz300001"""
        code = ticker.lower().replace("sh", "").replace("sz", "").replace("bj", "").strip()
        if code.startswith("6") or code.startswith("688"):
            return "sh" + code
        return "sz" + code

    # =================================================================
    # 行情数据
    # =================================================================
    @cached(ttl=1800)
    def get_stock_data(self, ticker: str, start_date: str, end_date: str) -> dict:
        """获取 A 股日线 K 线 (腾讯财经, 前复权)

        API: https://web.ifzq.gtimg.cn/appstock/app/fqkline/get
        返回格式: [date, open, close, high, low, volume]

        Args:
            ticker: 股票代码 (如 "600584")
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)

        Returns:
            {"data": [...], "columns": [...], "source": "tencent"} 或 {}
        """
        try:
            import requests

            symbol = self._tencent_symbol(ticker)
            sd = start_date.replace("-", "")
            ed = end_date.replace("-", "")
            url = (
                f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
                f"param={symbol},day,{start_date},{end_date},640,qfq"
            )
            resp = requests.get(url, timeout=self._timeout)
            resp.raise_for_status()
            data = resp.json()

            # 解析: data -> {symbol -> {qfqday or day -> [[...]]}}
            symbol_data = data.get("data", {}).get(symbol, {})
            kline = symbol_data.get("qfqday") or symbol_data.get("day") or []
            if not kline:
                return {}

            # 腾讯 K 线格式: [date, open, close, high, low, volume]
            records = []
            for row in kline:
                if len(row) < 6:
                    continue
                records.append({
                    "日期": row[0],
                    "开盘": float(row[1]),
                    "收盘": float(row[2]),
                    "最高": float(row[3]),
                    "最低": float(row[4]),
                    "成交量": float(row[5]),
                })

            if not records:
                return {}

            # 按日期过滤 (API 可能返回超出范围的数据)
            records = [r for r in records if start_date <= r["日期"] <= end_date]
            records = records[-30:]  # 最近 30 条

            return {
                "data": records,
                "columns": ["日期", "开盘", "收盘", "最高", "最低", "成交量"],
                "source": "tencent",
            }
        except Exception as e:
            logger.debug(f"[腾讯] get_stock_data 失败 ({ticker}): {e}")
            return {}

    @cached(ttl=300)
    def get_stock_info(self, ticker: str) -> dict:
        """获取股票实时行情摘要 (腾讯财经)

        API: https://qt.gtimg.cn/q=sz000001
        返回: 名称/现价/涨跌幅/成交量/总市值/流通市值等

        Args:
            ticker: 股票代码

        Returns:
            {"info": {...}, "source": "tencent"} 或 {}
        """
        try:
            import requests

            symbol = self._tencent_symbol(ticker)
            url = f"https://qt.gtimg.cn/q={symbol}"
            resp = requests.get(url, timeout=self._timeout)
            resp.raise_for_status()
            text = resp.text

            # 解析: v_sz000001="1~平安银行~000001~10.50~10.30~10.40~..."
            if "~" not in text:
                return {}

            parts = text.split("~")
            if len(parts) < 50:
                return {}

            # 腾讯实时行情字段索引 (关键部分)
            # 1:名称 2:代码 3:现价 4:昨收 5:今开 6:成交量(手) 7-9:买卖盘
            # 32:总市值 33:流通市值 38:涨跌幅 43:市盈率 44:市净率 46:换手率
            name = parts[1] if len(parts) > 1 else ""
            code = parts[2] if len(parts) > 2 else ticker
            price = parts[3] if len(parts) > 3 else "0"
            prev_close = parts[4] if len(parts) > 4 else "0"
            open_price = parts[5] if len(parts) > 5 else "0"
            volume = parts[6] if len(parts) > 6 else "0"
            total_mv = parts[45] if len(parts) > 45 else "0"  # 总市值(万)
            circ_mv = parts[44] if len(parts) > 44 else "0"   # 流通市值(万)
            pe = parts[39] if len(parts) > 39 else "0"
            pb = parts[46] if len(parts) > 46 else "0"

            info = {
                "证券代码": str(code),
                "股票简称": str(name),
                "现价": _safe_float_val(price),
                "昨收": _safe_float_val(prev_close),
                "今开": _safe_float_val(open_price),
                "成交量": _safe_float_val(volume),
                "总市值": _safe_float_val(total_mv),
                "流通市值": _safe_float_val(circ_mv),
                "市盈率": _safe_float_val(pe),
                "市净率": _safe_float_val(pb),
            }
            return {"info": info, "source": "tencent"}
        except Exception as e:
            logger.debug(f"[腾讯] get_stock_info 失败 ({ticker}): {e}")
            return {}

    # 以下方法腾讯 API 不直接支持, 返回 None (表示不支持, 不计熔断)
    def get_financial_data(self, ticker: str) -> dict:
        return None

    def get_dragon_tiger(self, date: str) -> dict:
        return None

    def get_fund_flow(self, ticker: str) -> dict:
        return None

    def get_sector_data(self) -> dict:
        return None

    def get_sector_stocks(self, sector: str) -> dict:
        return None

    def get_news(self, keyword: str = "", count: int = 20) -> dict:
        return None

    def get_market_index(self, symbol: str = "sh000001") -> dict:
        """获取大盘指数 (腾讯实时行情)"""
        try:
            import requests

            url = f"https://qt.gtimg.cn/q={symbol}"
            resp = requests.get(url, timeout=self._timeout)
            resp.raise_for_status()
            text = resp.text
            if "~" not in text:
                return {}

            parts = text.split("~")
            if len(parts) < 10:
                return {}

            name = parts[1] if len(parts) > 1 else ""
            price = _safe_float_val(parts[3]) if len(parts) > 3 else 0
            prev_close = _safe_float_val(parts[4]) if len(parts) > 4 else 0
            change_pct = _safe_float_val(parts[32]) if len(parts) > 32 else 0

            return {
                "data": {
                    "name": name,
                    "price": price,
                    "prev_close": prev_close,
                    "pct_change": change_pct,
                },
                "source": "tencent",
            }
        except Exception as e:
            logger.debug(f"[腾讯] get_market_index 失败 ({symbol}): {e}")
            return {}

    def get_market_movers(self) -> dict:
        return None


def _safe_float_val(val) -> float:
    """安全转 float, 失败返回 0"""
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0
