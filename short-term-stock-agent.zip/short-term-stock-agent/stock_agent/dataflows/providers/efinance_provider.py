"""
Efinance 数据源 (对应 PRD 6.10, 独立 fallback 数据源)

efinance 是开源 Python 财经数据接口库, 封装了东方财富/腾讯等数据源,
作为 AkShare 之外的独立 fallback。当 AkShare 网络抖动时提供二次覆盖。

支持方法:
  - get_stock_data  : 日线 K 线 (前复权)
  - get_fund_flow   : 个股资金流向 (主力/超大单/大单/中单/小单)
  - get_stock_info  : 股票基本信息

依赖: pip install efinance
所有方法 try/except 包裹, 失败返回空 dict (PRD: 工具优雅降级)。
"""
from loguru import logger

from stock_agent.dataflows.cache import cached


class EfinanceProvider:
    """Efinance 数据源 Provider (独立 fallback, 封装东财/腾讯多源)"""

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._ef = None

    @property
    def ef(self):
        """懒加载 efinance 模块"""
        if self._ef is None:
            try:
                import efinance as ef
                self._ef = ef
                logger.info("[Efinance] 模块加载成功")
            except ImportError:
                logger.warning("[Efinance] 模块未安装, 请 pip install efinance")
                raise
        return self._ef

    # =================================================================
    # 行情数据
    # =================================================================
    @cached(ttl=1800)
    def get_stock_data(self, ticker: str, start_date: str, end_date: str) -> dict:
        """获取 A 股日线 K 线 (efinance, 前复权)

        efinance 内部走 push2his.eastmoney.com, 与 AkShare 的 stock_zh_a_hist 同源,
        但实现独立 (不同的请求/解析逻辑), 在 AkShare 接口异常时提供二次覆盖。

        Args:
            ticker: 股票代码 (如 "600584")
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)

        Returns:
            {"data": [...], "columns": [...], "source": "efinance"} 或 {}
        """
        try:
            sd = start_date.replace("-", "")
            ed = end_date.replace("-", "")
            df = self.ef.stock.get_quote_history(ticker, beg=sd, end=ed)
            if df is None or df.empty:
                return {}

            # efinance 返回中文列名: 日期/开盘/收盘/最高/最低/成交量/成交额/振幅/涨跌幅/涨跌额/换手率
            records = df.tail(30).to_dict("records")
            columns = list(df.columns)
            return {"data": records, "columns": columns, "source": "efinance"}
        except Exception as e:
            logger.debug(f"[Efinance] get_stock_data 失败 ({ticker}): {e}")
            return {}

    @cached(ttl=300)
    def get_stock_info(self, ticker: str) -> dict:
        """获取股票基本信息 (efinance)

        通过实时行情获取名称/现价/市值等。
        """
        try:
            df = self.ef.stock.get_quote_history(ticker, klt=5)  # 5分钟K (近似实时)
            if df is None or df.empty:
                return {}
            row = df.iloc[-1].to_dict()
            name = str(row.get("股票名称", ""))
            price = _safe_float_val(row.get("收盘", 0))
            return {
                "info": {
                    "证券代码": ticker,
                    "股票简称": name,
                    "现价": price,
                },
                "source": "efinance",
            }
        except Exception as e:
            logger.debug(f"[Efinance] get_stock_info 失败 ({ticker}): {e}")
            return {}

    @cached(ttl=600)
    def get_fund_flow(self, ticker: str) -> dict:
        """获取个股资金流向 (efinance)

        efinance 封装东财资金流接口, 提供主力/超大单/大单/中单/小单净流入。
        """
        try:
            df = self.ef.stock.get_billboard_list(ticker)
            if df is None or df.empty:
                return {}
            records = df.to_dict("records")
            return {"data": records, "source": "efinance"}
        except Exception as e:
            logger.debug(f"[Efinance] get_fund_flow 失败 ({ticker}): {e}")
            return {}

    # 以下方法 efinance 不直接支持, 返回 None (表示不支持, 不计熔断)
    def get_financial_data(self, ticker: str) -> dict:
        return None

    def get_dragon_tiger(self, date: str) -> dict:
        return None

    def get_sector_data(self) -> dict:
        return None

    def get_sector_stocks(self, sector: str) -> dict:
        return None

    def get_news(self, keyword: str = "", count: int = 20) -> dict:
        return None

    def get_market_index(self, symbol: str = "sh000001") -> dict:
        return None

    def get_market_movers(self) -> dict:
        return None


def _safe_float_val(val) -> float:
    """安全转 float, 失败返回 0"""
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0
